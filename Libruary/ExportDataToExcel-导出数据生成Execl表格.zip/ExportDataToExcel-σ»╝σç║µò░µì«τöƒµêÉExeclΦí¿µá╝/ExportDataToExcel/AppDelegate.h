//
//  AppDelegate.h
//  ExportDataToExcel
//
//  Created by ningcol on 10/13/16.
//  Copyright © 2016 ningcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


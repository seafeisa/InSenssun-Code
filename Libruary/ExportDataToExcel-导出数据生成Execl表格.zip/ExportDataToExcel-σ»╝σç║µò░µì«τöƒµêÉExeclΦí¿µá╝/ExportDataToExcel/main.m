//
//  main.m
//  ExportDataToExcel
//
//  Created by ningcol on 10/13/16.
//  Copyright © 2016 ningcol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

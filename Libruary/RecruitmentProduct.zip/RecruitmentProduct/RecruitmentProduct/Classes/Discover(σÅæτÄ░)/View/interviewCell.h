//
//  interviewCell.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/22.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface interviewCell : UITableViewCell

/**
 *  重写cell方法
 */
+(instancetype)cellWithTableView:(UITableView *)tableView;




/**
 *  图片
 */
@property (nonatomic, strong) UIImageView *picImage;

/**
 *  题目
 */
@property (nonatomic, strong) UILabel *tmLabel;


@property (nonatomic, strong) NSString *type;


- (void)setSele:(BOOL)sele;



@end

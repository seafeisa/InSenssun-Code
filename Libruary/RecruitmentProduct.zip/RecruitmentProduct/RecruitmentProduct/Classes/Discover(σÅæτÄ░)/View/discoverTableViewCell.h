//
//  discoverTableViewCell.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/12.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface discoverTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UIImageView *titleIamgeView;

// 4.15新增 后面小箭头图片
@property (nonnull, strong) UIImageView *jtImageView;

@end

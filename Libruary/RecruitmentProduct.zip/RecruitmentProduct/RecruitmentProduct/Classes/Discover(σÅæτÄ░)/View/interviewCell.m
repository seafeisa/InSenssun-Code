//
//  interviewCell.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/22.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.22新增
 */

#import "interviewCell.h"
#import "Common.h"
#import "UIView+ZYFrame.h"

@implementation interviewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.height = 70;
        [self addSubViews];
    }
    return self;
}

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *identifier = @"interviewCell";
    id cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    
    
    
//    [cell setEditing:YES animated:YES];
    return cell;
}

- (void)addSubViews
{
    _picImage = [[UIImageView alloc] init];
    _picImage.image = [UIImage imageNamed:@"11111111111"];
//    _picImage.hidden = YES;

    [self.contentView addSubview:_picImage];
    
    _tmLabel = [[UILabel alloc] init];
    _tmLabel.text = @"啦啦啦";
    _tmLabel.numberOfLines = 0;
//    _tmLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_tmLabel];
    
    
    
}




- (void)layoutSubviews
{
//    [self addSubViews];
    
    _tmLabel.font = [UIFont systemFontOfSize:14.0];
//    _tmLabel.textColor = Color(138, 138, 138);
    _tmLabel.x = 50;
    _tmLabel.y = 0;
    _tmLabel.height = 70;
//    [_tmLabel sizeToFit];
    _tmLabel.width = screenW - 60;
    
    
    _picImage.x = 10;
    _picImage.y = 22;

    _picImage.width = 25;
    _picImage.height = 25;
}
- (void)setSele:(BOOL)sele
{
    if (sele) {
//        _picImage.hidden = NO;
        _picImage.image = [UIImage imageNamed:@"222222222222"];
    } else {
        _picImage.image = [UIImage imageNamed:@"11111111111"];
//        _picImage.hidden = YES;
    }

}

//- (void)awakeFromNib {
//    [super awakeFromNib];
//    [self addSubViews];
//    _tmLabel.font = [UIFont systemFontOfSize:14.0];
//    //    _tmLabel.textColor = Color(138, 138, 138);
//    _tmLabel.x = 50;
//    _tmLabel.y = 0;
//    _tmLabel.height = 70;
//    //    [_tmLabel sizeToFit];
//    _tmLabel.width = screenW - 60;
//    
//    
//    _picImage.x = 10;
//    _picImage.y = 22;
//    _picImage.width = 18;
//    _picImage.height = 25;
//    // Initialization code
//    
//}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//    [super setSelected:selected animated:animated];
//
//    // Configure the view for the selected state
//}

@end

//
//  sendPTModel.h
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface sendPTModel : NSObject
@property (nonatomic, copy) NSString *jobId;

@property (nonatomic, copy) NSString *companyId;

@property (nonatomic, copy) NSString *jobName;

@property (nonatomic, copy) NSString *jobDesc;

@property (nonatomic, copy) NSString *jobMainType;

@property (nonatomic, assign) int personCount;

@property (nonatomic, copy) NSString *partTime;

@property (nonatomic, copy) NSString *salary;

@property (nonatomic, copy) NSString *salaryType;

@property (nonatomic, copy) NSString *salaryPay;

@property (nonatomic, copy) NSString *partTimeBegin;

@property (nonatomic, copy) NSString *partTimeEnd;

@property (nonatomic, copy) NSString *isLong;

@property (nonatomic, copy) NSString *jobArea;

@property (nonatomic, copy) NSString *jobAddress;

@property (nonatomic, copy) NSString *receiveEmail;

@property (nonatomic, copy) NSString *linkman;

@property (nonatomic, copy) NSString *linkmanPhone;

@property (nonatomic, copy) NSString *releaseStatus;

@property (nonatomic, copy) NSString *latitude;

@property (nonatomic, copy) NSString *longitude;
@end

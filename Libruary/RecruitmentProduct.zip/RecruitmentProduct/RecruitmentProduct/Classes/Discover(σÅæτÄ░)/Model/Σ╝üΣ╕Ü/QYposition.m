//
//  QYposition.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/27.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "QYposition.h"

@implementation QYposition

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end

//
//  sendNewPostKeyModel.m
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//
/**
 *  职位发布参数模型
 */

#import "sendNewPostKeyModel.h"

@implementation sendNewPostKeyModel

@end

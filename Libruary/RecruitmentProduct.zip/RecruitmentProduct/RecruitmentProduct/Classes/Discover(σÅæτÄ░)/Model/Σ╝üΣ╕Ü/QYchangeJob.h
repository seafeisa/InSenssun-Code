//
//  QYchangeJob.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QYchangeJob : NSObject

/**
 *  education = ;
	jobMainType = 销售代表;
	publishAreaId = 2-52-500;
	publishAreaName = 北京-北京-东城区;
	filePath = http://192.168.100.2/enterprise/images/124DE5604A4211E5A220F8A506B91610/2016/04/1461723881266.jpg;
	positonCode = 001001001;
	publishDate = 2016-04-27;
	brightTag = 五险一金,年底双薪,绩效奖金,年终分红,股票期权,;
	puDate = ;
	companyType = 代表处;
	latitude = ;
	companyId = 124DE5604A4211E5A220F8A506B91610;
	companyAddress = 北京       sdgfdsfgdsf                              ;
	isAudit = 01;
	jobName = 人力资源经理人力资源经理人力资源经理人力资源经理人力资源经理;
	salary = 4000-6000元;
	jobNature = 全职招聘;
	companyUrl = www.baidu.com;
	jobPhone = 13288888888;
	longitude = ;
	companyName = 中国工商银行股份有限公司;
	contactInfo = 公司名称：中国工商银行股份有限公司
	departId = ;
	compnayPersons = 500-999人;
	personCount = 1;
	jobDesc = 选择只为亮点，提升职位吸引力，有效增加至未投递</span>;
	jobArea = 北京市崇文区;
	experience = ;
	jobTelephone = 18337108858;
	mainIndustry = 计算机硬件及网络设备;
	jobId = 7290D8C0BF1211E598C0823FC2B518A1;
	companyDesc = <p style="font-family:微软雅黑;font-size:
 */

//







/**
*  职位性质
*/
@property (nonatomic, strong) NSString *jobNature;

/**
 *  职位名称
 */
@property (nonatomic, strong) NSString *jobName;

/**
 *  职位类别
 */
@property (nonatomic, strong) NSString *jobMainType;


/**
*  招聘人数
*/
@property (nonatomic, assign) NSInteger personCount;

/**
*  学历
*/
@property (nonatomic, strong) NSString *education;

/**
*  经验要求
*/

@property (nonatomic, strong) NSString *experience;

/**
*  职位月薪
*/
@property (nonatomic, strong) NSString *salary;

/**
*  职位描述
*/
@property (nonatomic, strong) NSString *jobDesc;


/**
*  亮点标签
*/
@property (nonatomic, strong) NSString *brightTag;

/**
*  职位发布地点
*/
@property (nonatomic, strong) NSString *publishAreaName;

/**
*  简历接收设置
*/
@property (nonatomic, strong) NSString *receiveSet;

/**
*  职位申请回复
*/
@property (nonatomic, strong) NSString *jobReply;


/**
*  工作地址
*/
@property (nonatomic, strong) NSString *jobArea;


/**
*  联系方式
*/
@property (nonatomic, strong) NSString *contactInfo;

/**
*  职位编号
*/
@property (nonatomic, strong) NSString *jobNum;

/**
*  企业自己职位排序
*/
@property (nonatomic, strong) NSString *sort;

/**
*  简历截止日期
*/
@property (nonatomic, strong) NSString *finallyDate;


@property (nonatomic, strong) NSString *publishAreaId;








@end

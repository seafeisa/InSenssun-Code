//
//  QYposition.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/27.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QYposition : NSObject


/**
 *  publishAreaName = 北京-西城区;
	agentArea = ;
	latitude = ;
	topSort = 0;
	jobMainType = 001001001;
	provinceCode = ;
	sb = ;
	agentType = ;
	companyName = ;
	contactInfo = dddddddddddddddddd;
	cityName = ;
	countResumeNum = 0;
	finallyDate = 2017-03-03;
	jobId = 42D4B2804FA211E5AD909313994D460B;
	releaseStatus = 01;
	companyId = 535662D0416911E5A076F8F061532E9D;
	experience = ;
	topEndDate = <null>;
	jobArea = 郑州市桐柏路与西站路交叉口;
	longitude = ;
	currentpage = 1;
	buginCreateDate = ;
	jobNum = ;
	createPerson = ssss11;
	jobDesc = 东方大学是范德萨的神烦大叔;
	fullText = ;
	rscount = 0;
	countyName = ;
	sort = 1;
	publishAreaId = 52-501;
	departId = ;
	personCount = 3;
	receiveSet = 01;
	education = ;
	salary = 08;
	updateDate = 2016-04-26 16:29:37.0;
	updatePerson = ;
	isAudit = 01;
	templateId = 0190CFA0447811E58FA098CE50C727A2;
	brightTag = 01,02,03,04;
	createDate = 2015-08-31 14:19:04.0;
	filterId = 01908180447811E581808345933563AE;
	jobReply = 01;
	buginFinallyDate = ;
	jobSecondType = 001001001;
	endFinallyDate = ;
	jobNature = 01;
	jobState = 01;
	jobName = 销售4;
	publishDate = 2016-04-26 16:29:36;
	releaseTime = ;
	filePath = ;
	publishArea = ;
	companyArea = ;
	endCreateDate = ;
	jobCity = ;
	receiveEmail = ;
	seeCount = 0;
 */


/**
*  职位名称
*/

@property (nonatomic, strong) NSString *jobName;

/**
*  工作地址
*/

@property (nonatomic, strong) NSString *publishAreaName;

/**
*  学历
*/

@property (nonatomic, strong) NSString *education;

/**
*  经验要求
*/

@property (nonatomic, strong) NSString *experience;

/**
*  简历截止日期
*/

@property (nonatomic, strong) NSString *finallyDate;

/**
 *  投递人数
 */

@property (nonatomic, strong) NSString *countResumeNum;

/**
 *  职位性质
 */
@property (nonatomic, strong) NSString *jobNature;


/**
 *  职位类别
 */
@property (nonatomic, strong) NSString *jobMainType;

/**
 *  招聘人数
 */
@property (nonatomic, strong) NSString *personCount;

/**
 *  职位月薪
 */
@property (nonatomic, strong) NSString *salary;

/**
 *  职位描述
 */
@property (nonatomic, strong) NSString *jobDesc;


/**
 *  亮点标签
 */
@property (nonatomic, strong) NSString *brightTag;


/**
 *  职位发布地点
 */
@property (nonatomic, strong) NSString *publishArea;

/**
 *  简历接收设置
 */
@property (nonatomic, strong) NSString *receiveSet;

/**
 *  高级发布设置
 */
//@property (nonatomic, strong) <#type#> *<#name#>;


/**
 *  职位申请回复
 */
@property (nonatomic, strong) NSString *jobReply;


/**
 *  工作地址
 */
@property (nonatomic, strong) NSString *jobArea;


/**
 *  联系方式
 */
@property (nonatomic, strong) NSString *contactInfo;

/**
 *  职位编号
 */
@property (nonatomic, strong) NSString *jobNum;

/**
 *  企业自己职位排序
 */
@property (nonatomic, strong) NSString *sort;

/**
 *  职位发布状态
 */
@property (nonatomic, strong) NSString *releaseStatus;

/**
 *  职位ID
 */
@property (nonatomic, strong) NSString *jobId;

@property (nonatomic, strong) NSString *companyId;



@end

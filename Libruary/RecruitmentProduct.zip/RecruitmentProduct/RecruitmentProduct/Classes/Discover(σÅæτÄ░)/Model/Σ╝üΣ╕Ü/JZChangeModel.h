//
//  JZChangeModel.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZChangeModel : NSObject

/**
 *  createPerson = ssss11;
	partTimeBegin = 2015-10-27 00:27:00;
	endCreateDate = ;
	jobTelephone = 18700000007;
	pageEnd = 0;
	jobState = 01;
	jobArea = 501,540;
	publishDate = 2016-04-27 16:27:00;
	jobName = 4;
	personCount = 6;
	salaryStr = ;
	jobId = 9E39F5D04C8811E5B5D0B0A186B403EE;
	personCountStr = ;
	jobAreaId = 2-52-501,4-55-540;
	salary = 90;
	endFinallyDate = ;
	companyArea = 36;
	updateDate = 2016-04-27 16:47:17.0;
	beginFinallyDate = ;
	jobMainType = 销售代表;
	partTimeEnd = ;
	positonCode = 001001001;
	linkman = 王先生;
	salaryPay = 日结;
	companyAddress = 北京市山阳区;
	partTime = 001,002,003,004,005,011,022,033,044,055,111,222,333,444,555;
	longitude = 113.680585;
	linkmanPhone = 18000000000;
	releaseStatus = 01;
	beginCreateDate = ;
	companyId = 535662D0416911E5A076F8F061532E9D;
	pageStart = 0;
	updatePerson = ssss11;
	companyType = 国企;
	companyUrl = ;
	createDate = 2015-08-27 14:55:35.0;
	compnayPersons = 1000-9999人;
	jobAreaName = 北京-西城区,福建-南平-武夷山市;
	partTimeBeginStr = ;
	receiveEmail = s1@qq.com;

 */
   //



/**
*  职位地址
*/
@property (nonatomic, strong) NSString *jobAddress;

/**
 *  职位名称
 */
@property (nonatomic, strong) NSString *jobName;

/**
 *  职位类别
 */
@property (nonatomic, strong) NSString *jobMainType;

/**
 *  招聘人数
 */
@property (nonatomic, assign) NSInteger personCount;

/**
 *  兼职时间
 */
@property (nonatomic, strong) NSString *partTime;

/**
 *  薪资水平
 */
@property (nonatomic, assign) NSInteger salary;

/**
 *  薪资结算
 */
@property (nonatomic, strong) NSString *salaryPay;

/**
 *  开始日期
 */
@property (nonatomic, strong) NSString *partTimeBeginStr;

/**
 *  结束日期
 */
@property (nonatomic, strong) NSString *partTimeEndStr;

/**
 *  职位描述
 */
@property (nonatomic, strong) NSString *jobDesc;

/**
 *  职位发布地点
 */
@property (nonatomic, strong) NSString *jobAreaName;

/**
 *  联系人
 */
@property (nonatomic, strong) NSString *linkman;

/**
 *  联系电话
 */
@property (nonatomic, strong) NSString *linkmanPhone;

/**
 *  简历接收邮箱
 */
@property (nonatomic, strong) NSString *receiveEmail;


@end

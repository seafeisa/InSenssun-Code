//
//  sendNewPostKeyModel.h
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface sendNewPostKeyModel : NSObject
@property (nonatomic, copy) NSString *companyId;

@property (nonatomic, copy) NSString *releaseStatus;

@property (nonatomic, copy) NSString *jobNature;

@property (nonatomic, copy) NSString *jobName;

@property (nonatomic, copy) NSString *jobMainType;

@property (nonatomic, copy) NSString *jobSecondType;

//@property (nonatomic, copy) NSString *personCount;

@property (nonatomic, assign) int personCount;

@property (nonatomic, copy) NSString *education;

@property (nonatomic, copy) NSString *experience;

@property (nonatomic, copy) NSString *salary;

@property (nonatomic, copy) NSString *jobDesc;

@property (nonatomic, copy) NSString *brightTag;

@property (nonatomic, copy) NSString *publishAreaId;

@property (nonatomic, copy) NSString *jobArea;

@property (nonatomic, copy) NSString *latitude;

@property (nonatomic, copy) NSString *longitude;

@property (nonatomic, copy) NSString *finallyDate;

@property (nonatomic, copy) NSString *receiveSet;

@property (nonatomic, copy) NSString *receiveEmail;

@property (nonatomic, copy) NSString *jobNum;


@property (nonatomic, copy) NSString *jobReply;

@property (nonatomic, copy) NSString *contactInfo;

@property (nonatomic, copy) NSString *filterName;

@property (nonatomic, copy) NSString *beginAge;

@property (nonatomic, copy) NSString *endAge;

@property (nonatomic, copy) NSString *sex;

@property (nonatomic, copy) NSString *lowestEducation;

@property (nonatomic, copy) NSString *highestEducation;

@property (nonatomic, copy) NSString *lowestYears;

@property (nonatomic, copy) NSString *highestYears;

@property (nonatomic, copy) NSString *resideArea;

@property (nonatomic, copy) NSString *domicilePlace;

@property (nonatomic, copy) NSString *marriage;

@property (nonatomic, copy) NSString *resumeVersion;

@property (nonatomic, copy) NSString *isFitler;



@end

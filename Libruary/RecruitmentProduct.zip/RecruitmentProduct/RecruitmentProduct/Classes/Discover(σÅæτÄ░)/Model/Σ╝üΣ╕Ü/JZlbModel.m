//
//  JZlbModel.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JZlbModel.h"

@implementation JZlbModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end

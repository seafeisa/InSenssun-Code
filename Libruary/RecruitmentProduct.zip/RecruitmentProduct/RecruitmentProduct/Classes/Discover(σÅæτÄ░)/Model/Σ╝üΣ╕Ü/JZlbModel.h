//
//  JZlbModel.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZlbModel : NSObject

/**
 *  职位名称
 */
@property (nonatomic, strong) NSString *jobName;

/**
 *  兼职地点
 */
@property (nonatomic, strong) NSString *JobAddress;

/**
 *  兼职结束时间
 */
@property (nonatomic, strong) NSString *partTimeEndStr;

@property (nonatomic, assign) int personCount;

@end

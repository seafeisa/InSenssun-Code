//
//  sendPTModel.m
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//
/**
 *  兼职发布上传参数模型
 */

#import "sendPTModel.h"

@implementation sendPTModel





@end

//
//  adviceModel.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/22.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface adviceModel : NSObject

/**
 *
    pictureOldName = ;
	pictureNewName = ;
	careerSource = ;
	contentAbstract = ;
	createPerson = ;
	isHot = ;
	articleTypeId = ;
	articleTitle = fghggggggggg;
	articleTypeName = ;
	file = <null>;
	articleState = ;
	fileContentType = ;
	fileFileName = ;
	isAttachment = ;
	rscount = 0;
	articleContent = ;
	picturePathName = ;
	updateDate = ;
	updatePerson = ;
	currentpage = 1;
	fileOldName = ;
	parentTypeId = ;
	filePathName = ;
	careerAdviceId = B074D020F62011E590209350DF2094C6;
	viewImage = ;
	parentTypeName = ;
	readHits = 0;
	recommend = ;
	createDate = ;
	attachmentName = ;
	publishDate = ;
	fileNewName = ;
 */



     // 4.22新增

/**
*  文章名称
*/
@property (nonatomic, strong) NSString *articleTitle;

/**
 *  日期
 */
@property (nonatomic, strong) NSString *publishDate;

/**
 *  文章内容
 */
@property (nonatomic, strong) NSString *articleContent;

/**
 *  careerAdviceId
 */
@property (nonatomic, strong) NSString *careerAdviceId; 

@end

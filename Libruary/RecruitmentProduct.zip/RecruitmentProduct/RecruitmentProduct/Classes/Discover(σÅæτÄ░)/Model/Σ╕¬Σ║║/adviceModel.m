//
//  adviceModel.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/22.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "adviceModel.h"

@implementation adviceModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end

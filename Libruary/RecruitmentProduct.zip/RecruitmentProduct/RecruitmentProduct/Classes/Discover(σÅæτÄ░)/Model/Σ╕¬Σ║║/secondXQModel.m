//
//  secondXQModel.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/21.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "secondXQModel.h"

@implementation secondXQModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end

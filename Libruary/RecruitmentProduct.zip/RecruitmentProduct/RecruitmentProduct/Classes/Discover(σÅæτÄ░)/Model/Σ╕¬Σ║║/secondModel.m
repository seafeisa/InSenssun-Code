//
//  secondModel.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/20.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "secondModel.h"

@implementation secondModel

//-(instancetype)initWithModelWithDictionary:(NSDictionary *)dict{
//    if (self = [super init]) {
//        
//    }
//    return self;
//}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end

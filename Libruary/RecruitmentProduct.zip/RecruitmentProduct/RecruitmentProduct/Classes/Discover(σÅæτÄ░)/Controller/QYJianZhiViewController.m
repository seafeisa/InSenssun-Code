//
//  QYJianZhiViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//


/**
 *  4.29新增 企业兼职列表
 */

#import "QYJianZhiViewController.h"
#import "QYpositionTableViewCell.h"
#import "Common.h"
#import "zyzpHttpTool.h"
#import "Account.h"
#import "DTKDropdownMenuView.h"
#import <MJRefresh.h>
#import "JZlbModel.h"
#import "publishViewController.h"
#import "JZChangeModel.h"
#import "partTimeDetailC.h"
#import <UIImageView+WebCache.h>


@interface QYJianZhiViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSString *viewState;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSMutableArray *jobIDArray;

@property (nonatomic, strong) NSMutableArray *companyIdArray;


@end

@implementation QYJianZhiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _viewState = @"0";
    [self addSubView];
    [self addMenuView];
//    [self getDataForUrl];
    
}

- (void)getDataForUrlla
{
    NSString *url = [baseUrl stringByAppendingString:@"selectPhonePartTimeJobList.htm"];
    NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
    parameters[@"sb"] = _viewState;
    
    [zyzpHttpTool GET:url parameters:parameters progress:^{
        
    } success:^(id responseObject) {
        MYLog(@"%@", responseObject);
        self.dataArray = [NSMutableArray array];
        self.jobIDArray = [NSMutableArray array];
        _companyIdArray = [NSMutableArray array];
        NSArray *arr = responseObject;
        for (NSDictionary *dic in arr) {
            JZlbModel *model = [[JZlbModel alloc] init];
            NSString *str = dic[@"jobId"];
            NSString *companyId = dic[@"companyId"];
            [model setValuesForKeysWithDictionary:dic];
            [self.dataArray addObject:model];
            [self.jobIDArray addObject:str];
            [_companyIdArray addObject:companyId];
        }
        [self.tableView reloadData];
        
        [self.tableView.mj_header endRefreshing];
        
    } failure:^(NSError *error) {
        
    }];
}




- (void)addMenuView
{
    DTKDropdownItem *item0 = [DTKDropdownItem itemWithTitle:@"发布中的兼职" callBack:^(NSUInteger index, id info) {
        _viewState = @"0";
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
        
    }];
    DTKDropdownItem *item1 = [DTKDropdownItem itemWithTitle:@"已暂停的兼职" callBack:^(NSUInteger index, id info) {
        _viewState = @"1";
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownItem *item2 = [DTKDropdownItem itemWithTitle:@"未发布的兼职" callBack:^(NSUInteger index, id info) {
        _viewState = @"2";
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownItem *item3 = [DTKDropdownItem itemWithTitle:@"发布结束兼职" callBack:^(NSUInteger index, id info) {
        _viewState = @"3";
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    
    DTKDropdownMenuView *menuView = [DTKDropdownMenuView dropdownMenuViewForNavbarTitleViewWithFrame:CGRectMake(0, 0, 200.f, 44.f) dropdownItems:@[item0,item1,item2,item3]];
    menuView.currentNav = self.navigationController;
    menuView.dropWidth = screenH / 2 + 64;
    menuView.titleFont = [UIFont systemFontOfSize:18.f];
    menuView.textColor =  ColorWithRGB(102.f, 102.f, 102.f);
    menuView.textFont = [UIFont systemFontOfSize:13.f];
    
    menuView.cellSeparatorColor = [UIColor orangeColor];
    menuView.textFont = [UIFont systemFontOfSize:14.f];
    
    menuView.animationDuration = 0.3f;
    menuView.selectedIndex = 0;
    self.navigationItem.titleView = menuView;
}


- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(getDataForUrlla)];
    [self.tableView.mj_header beginRefreshing];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 86;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    JZlbModel *model = self.dataArray[indexPath.row];
    
    QYpositionTableViewCell *cell = [QYpositionTableViewCell cellWithTableView:tableView];
    
    [cell.topImageView sd_setImageWithURL:[NSURL URLWithString:_conLogo]];
    cell.numberLabel.text = [NSString stringWithFormat:@"%d", model.personCount];
    cell.nameLable.text = model.jobName;
    cell.addressLabel.text = model.JobAddress;
    cell.dateLabel.text = model.partTimeEndStr;
//    cell.numberLabel.text = 
    
    return cell;
}

- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_viewState isEqualToString:@"0"]) {
        UITableViewRowAction *deleteRowAction = [UITableViewRowAction rowActionWithStyle:(UITableViewRowActionStyleDestructive) title:@"刷新" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"updatePhoneJobPublishDate.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];
            [self.tableView reloadData];
        
        }];
        
        UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"暂停" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            
            NSString *url = [baseUrl stringByAppendingString:@"changePhoneJobStateStop.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];

//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
            
        }];
        
        
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"修改" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"selectPhonePartTimeJobDetail.htm"];
            NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
            parameter[@"jobId"] = self.jobIDArray[indexPath.row];
            MYLog(@"%@", self.jobIDArray[indexPath.row]);
            [zyzpHttpTool GET:url parameters:parameter progress:^{
                
            } success:^(id responseObject) {
                
                MYLog(@"%@", responseObject);
                JZChangeModel *model = [[JZChangeModel alloc] init];
                [model setValuesForKeysWithDictionary:responseObject];
                
                publishViewController *publishVC = [[publishViewController alloc] init];
                publishVC.model = model;
                publishVC.idididid = self.jobIDArray[indexPath.row];
                [self.navigationController pushViewController:publishVC animated:YES];
                [self.tableView reloadData];
                
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
        
            [self.tableView reloadData];
            
            
        }];
        deleteRowAction.backgroundColor = Color(255, 178, 0);
        editRowAction.backgroundColor = Color(94, 163, 118);
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[deleteRowAction, editRowAction, beginRowAction];
    } else if ([_viewState isEqualToString:@"1"]){
        
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"恢复" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"updatePhoneJobStateOpen.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{    
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                
                [self.tableView reloadData];
            } failure:^(NSError *error) {
            }];
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
            
        }];
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[beginRowAction];
    } else if ([_viewState isEqualToString:@"2"]) {
        UITableViewRowAction *deleteRowAction = [UITableViewRowAction rowActionWithStyle:(UITableViewRowActionStyleDestructive) title:@"删除" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"deletePhoneUnpublishedPTJob.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];
            
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
        }];
        
        UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"发布" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            
            NSString *url = [baseUrl stringByAppendingString:@"releaseJobPhone.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
            
        }];
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"修改" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"selectPhonePartTimeJobDetail.htm"];
            NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
            parameter[@"jobId"] = self.jobIDArray[indexPath.row];
            MYLog(@"%@", self.jobIDArray[indexPath.row]);
            [zyzpHttpTool GET:url parameters:parameter progress:^{
                
            } success:^(id responseObject) {
                
                MYLog(@"%@", responseObject);
                JZChangeModel *model = [[JZChangeModel alloc] init];
                [model setValuesForKeysWithDictionary:responseObject];
                
                publishViewController *publishVC = [[publishViewController alloc] init];
                publishVC.model = model;
                publishVC.idididid = self.jobIDArray[indexPath.row];
                [self.navigationController pushViewController:publishVC animated:YES];
                [self.tableView reloadData];
                
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
            [self.tableView reloadData];
        }];
        deleteRowAction.backgroundColor = Color(255, 178, 0);
        editRowAction.backgroundColor = Color(94, 163, 118);
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[deleteRowAction, editRowAction, beginRowAction];
    }
    return nil;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    partTimeDetailC *partVC = [[partTimeDetailC alloc] init];
    partVC.jobId = _jobIDArray[indexPath.row];
    [self.navigationController pushViewController:partVC animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

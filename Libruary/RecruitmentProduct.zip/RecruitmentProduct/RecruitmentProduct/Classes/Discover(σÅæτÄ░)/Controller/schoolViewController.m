//
//  schoolViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/12.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  找工作--校园招聘

#import "schoolViewController.h"
#import "Common.h"
#import "schoolTableViewCell.h"
#import "zyzpHttpTool.h"
#import "schoolModel.h"
#import "UIImageView+WebCache.h"
#import "postDetailController.h"
#import <MJRefresh.h>
#import "AppDelegate.h"


@interface schoolViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSArray *schoolArray;

@property (nonatomic, strong) NSString *school;

@property (nonatomic, strong) NSString *city;

@property (nonatomic, assign) int num;

@property (nonatomic, strong) NSMutableArray *allArray;

@end

@implementation schoolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 4.15 新增 title
    [self getDataForJson];
    _num = 1;
    _cityKey = [appDelegate.appDefault objectForKey:@"toOtherStrLocation"];;
    self.title = @"校园招聘";
    [self getDataForUrl];
    [self addSubView];
    [self setUpRefreshLoadMoreData:@selector(getDataForUrl)];
    self.navigationController.navigationBar.translucent = YES;
    
}


/**
 *  4.21新增 请求数据
 */
- (void)getDataForUrl
{
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"cityName"] = _cityKey;
    NSString *str = [baseUrl stringByAppendingString:@"selectPhoneTopJobByPractice.htm"];
    MYLog(@"%@", _cityKey);
    [zyzpHttpTool GET:str parameters:parameters progress:^{
        
    } success:^(id responseObject) {
//        MYLog(@"%@", responseObject);
        NSArray *arr = [NSArray arrayWithArray:responseObject];
//         MYLog(@"%@", arr);
//         MYLog(@"%@", arr.lastObject);
        self.dataArray = [NSMutableArray array];
        for (NSDictionary *dic in arr) {
            schoolModel *model = [[schoolModel alloc] init];
            [model setValuesForKeysWithDictionary:dic];
            [self.dataArray addObject:model];
            
        }
        [self.allArray addObjectsFromArray:_dataArray];
        [self.tableView reloadData];
        [self.tableView.mj_footer endRefreshing];
        _num = _num + 1;
        
    } failure:^(NSError *error) {
        
    }];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"education" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    _schoolArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
}

/**
 *  4.19改动
 */


- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 122)];
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenW, 122)];
    image.image = [UIImage imageNamed:@"xianyuan"];
    [view addSubview:image];
    
//    view.backgroundColor = zyMainColor;
    self.tableView.tableHeaderView = view;
    [self.view addSubview:self.tableView];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 86;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    schoolModel *model = self.dataArray[indexPath.row];
    schoolTableViewCell *cell = [schoolTableViewCell cellWithTableView:tableView];
    
    [cell.qyimage sd_setImageWithURL:[NSURL URLWithString:model.filePath]];
    cell.zwnameLable.text = model.jobName;
    cell.qynameLable.text = model.companyName;
    cell.addressLabel.text = model.publishAreaName;
    MYLog(@"%@", model.education);
    for (NSDictionary *dic in _schoolArray) {
        if ([dic[@"dicKey"] isEqualToString:model.education]) {
            _school = dic[@"dicValue"];
        }
    }
    cell.schoolLabel.text = _school;
    cell.dateLable.text = model.publishDate;
    cell.moneyLabel.text = [[NSString stringWithFormat:@"%ld", (long)model.salary] stringByAppendingString:@"k"];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    postDetailController *postDc = [postDetailController new];
     schoolModel *model = self.dataArray[indexPath.row];
    postDc.jobId = model.jobId;
    postDc.companyId = model.companyId;
    [self.navigationController pushViewController:postDc animated:YES];
    
}

-(void)setUpRefreshLoadMoreData:(SEL)loadDataAction{
    
    MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:loadDataAction];
    footer.automaticallyHidden = YES;
    //    footer.refreshingTitleHidden = YES;
    // 设置文字
    [footer setTitle:@"木有更多指缘数据了~" forState:MJRefreshStateIdle];
    [footer setTitle:@"加载更多指缘数据 ..." forState:MJRefreshStateRefreshing];
    [footer setTitle:@"木有更多指缘数据了~" forState:MJRefreshStateNoMoreData];
    //设置刷新图片
    //[footer setImages:refreshingImages forState:MJRefreshStateRefreshing];
    
    // 设置尾部
    self.tableView.mj_footer = footer;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  companyViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/12.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface companyViewController : UIViewController

@end

//
//  QYJobViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/15.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//
/**
 *  4.15日 新增企业发布职位
 */

#import "QYJobViewController.h"
#import "Common.h"
#import "UIView+ZYFrame.h"
#import "QYjobTableViewCell.h"
#import "newJobNameViewController.h"
#import "MHActionSheet.h"
#import "newJobNatureViewController.h"
#import "newJobClassViewController.h"
#import "newJobNumberViewController.h"
#import "newJobStudyViewController.h"
#import "newJobExpViewController.h"
#import "newJobWagesViewController.h"
#import "newJobWriteViewController.h"
#import "newJobTagViewController.h"
#import "newJobAddressViewController.h"
#import "newJobDateViewController.h"
#import "newJobAcceptViewController.h"
#import "newJobToppppViewController.h"
#import "newJobReplyViewController.h"
#import "newJobPlaceViewController.h"
#import "newJobPhoneViewController.h"
#import "MHDatePicker.h"
#import "zyzpHttpTool.h"
#import "Account.h"
#import <MJExtension.h>
#import "AppDelegate.h"
#import "sendNewPostKeyModel.h"
#import "ZWNameVC.h"
#import "ZWJobAddressVC.h"
#import "LCMbeanViewController.h"



@interface QYJobViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

// 表尾view
@property (nonatomic, strong) UIView *BWview;

// 名字array
@property (nonatomic, strong) NSArray *nameArray;
/**
 *  上传参数模型
 */
@property (nonatomic, strong) sendNewPostKeyModel *sendParamModel;
/**
 *  4.18新增 全局cell
 */
@property (nonatomic, strong) QYjobTableViewCell *cell;
/**
 *  招聘人数
 */
@property (nonatomic, strong)  UITextField *numberFiled;
/**
 *  4.25新增  JobName
 */
@property (nonatomic, strong) NSString *JobName;

/**
 *  招聘人数
 */
@property (nonatomic, strong) NSString *JobNumber;

/**
 *  学历要求
 */
@property (nonatomic, strong) NSString *JobStudy;

/**
 *  工作经验
 */
@property (nonatomic, strong) NSString *JobExp;

/**
 *  职位月薪
 */
@property (nonatomic, strong) NSString *JobWages;

/**
 *  职位描述
 */
@property (nonatomic, strong) NSString *JobWrite;

/**
 *  职位申请回复
 */
@property (nonatomic, strong) NSString *JobReply;

/**
 *  联系方式
 */
@property (nonatomic, strong) NSString *JobPhone;

/**
 *  简历接收设置
 */
@property (nonatomic, strong) NSString *JobAccept;

/**
 *  4.26 职位发布地点
 */
@property (nonatomic, strong) NSString *JobAddress;

/**
 *  职位类别
 */
@property (nonatomic, strong) NSString *JobClass;

/**
 *  工作地址
 */
@property (nonatomic, strong) NSString *JobPlace;




@property (nonatomic, strong) NSArray *allArray;


@property (nonatomic, strong) MHDatePicker *datePicker;


@property (nonatomic, strong) NSString *JobDate;


@property (nonatomic, copy) NSString *tagStrs;



// 职位类别数组
@property (nonatomic, strong) NSArray *zwlbArray;

// 学历数组
@property (nonatomic, strong) NSArray *xlArray;

// 经验要求数组
@property (nonatomic, strong) NSArray *jyyqArray;

// 职位月薪数组
@property (nonatomic, strong) NSArray *zwyxArray;

// 亮点标签数组
@property (nonatomic, strong) NSArray *ldbqArray;

// 简历接收设置
@property (nonatomic, strong) NSArray *jljsszArray;

// 职位申请恢复
@property (nonatomic, strong) NSArray *zwsqhfArray;

// 亮点标签mu
@property (nonatomic, strong) NSMutableArray *ldArray;


@end



@implementation QYJobViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // 4.15 新增 title
    self.title = @"发布新职位";
    self.nameArray = [NSArray array];
    self.nameArray = @[@"职位性质", @"职位名称", @"职位类别", @"招聘人数", @"学历要求", @"经验要求", @"职位月薪", @"职位描述", @"亮点标签", @"职位发布地点", @"发布截止日期", @"简历接收设置", @"职位申请回复", @"工作地址", @"联系方式"];
    
    
    
   _sendParamModel = [[sendNewPostKeyModel alloc] init];
    _ldArray = [NSMutableArray array];
    
    
    [self getdata];
    [self addUIView];
    [self addSubView];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self dataForJson];
    
    if (_model) {
        
        _sendParamModel.jobNature = _model.jobNature;
        _sendParamModel.jobName = _model.jobName;
        _sendParamModel.jobMainType = _model.jobMainType;
        //    MYLog(@"%ld", _model.personCount);
        _sendParamModel.personCount = (int)_model.personCount;
        _sendParamModel.education = _model.education;
        _sendParamModel.experience = _model.experience;
        _sendParamModel.salary = _model.salary;
        _sendParamModel.jobDesc = _model.jobDesc;
        _sendParamModel.brightTag = _model.brightTag;
        _sendParamModel.publishAreaId = _model.publishAreaId;
        _sendParamModel.finallyDate = _model.finallyDate;
        _sendParamModel.receiveSet = _model.receiveSet;
        _sendParamModel.jobReply = _model.jobReply;
        _sendParamModel.jobArea = _model.jobArea;
        _sendParamModel.contactInfo = _model.contactInfo;
    }
}

/**
 *  4.25新增
 */

- (void)getdata
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(valueFromNotifi:) name:@"JobNature" object:nil];
    // 职位名称
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobName:) name:@"ZWname" object:nil];
    // 招聘人数
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobNumber:) name:@"JobNumber" object:nil];
    // 学历要求
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobStudy:) name:@"JobStudy" object:nil];
    // 工作经验
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobExp:) name:@"JobExp" object:nil];
    // 职位月薪
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWages:) name:@"JobWages" object:nil];
    // 职位描述
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWrite:) name:@"JobWrite" object:nil];
    // 职位申请回复
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobReply:) name:@"JobReply" object:nil];
    // 联系方式
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobPhone:) name:@"JobPhone" object:nil];
    // 简历接收设置
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobAccept:) name:@"JobAccept" object:nil];
    // 4.26 职位发布地点
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobAddress:) name:@"JobAddress" object:nil];
    // 职位类别
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wzsJobClass:) name:@"JobName" object:nil];
    // 工作地址
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wzsJobPlace:) name:@"ZWJOB" object:nil];
    // 发布截止日期
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobDate:) name:@"JobDate" object:nil];

    // 亮点标签
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTagStrsFromNotifi:) name:@"tagStrsNotifi" object:nil];
}

/**
 *  4.25新增  好多通知方法😂
 */
- (void)valueFromNotifi:(NSNotification *)notifi{
    NSDictionary *dictionary = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobNature = dictionary[@"Nature"];
    _model.jobNature = dictionary[@"Nature"];
    _sendParamModel.jobNature = dictionary[@"natureKey"];
    [self.tableView reloadData];
}

/**
 *  职位名称
 */

- (void)JobName:(NSNotification *)notifi{
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobName = dic[@"zwname"];
    _model.jobName = dic[@"zwname"];
    _sendParamModel.jobName = dic[@"zwname"];
    [self.tableView reloadData];
}

/**
 *  学历要求
 */
- (void)JobStudy:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobStudy = dic[@"Study"];
    _model.education = dic[@"Study"];
    _sendParamModel.education = dic[@"studyKey"];
    [self.tableView reloadData];
}

// 招聘人数
- (void)JobNumber:(NSNotification *)notifi{
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobNumber = dic[@"Number"];
    _sendParamModel.personCount =  [[appDelegate.appDefault objectForKey:@"number"] intValue];
  //  MYLog(@"%@", _sendParamModel.personCount);
    _model.personCount = (NSInteger)dic[@"Number"];
    [self.tableView reloadData];
}

/**
 *  工作经验
 */
- (void)JobExp:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobExp = dic[@"Exp"];
    _model.experience = dic[@"Exp"];
    _sendParamModel.experience = dic[@"expKey"];
   // MYLog(@"%@",_sendParamModel.experience );
    [self.tableView reloadData];
}

/**
 *  职位月薪
 */
- (void)JobWages:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWages = dic[@"Wages"];
    _model.salary = dic[@"Wages"];
    _sendParamModel.salary = dic[@"salaryKey"];
    [self.tableView reloadData];
}

/**
 *  职位描述
 */
- (void)JobWrite:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWrite = dic[@"Write"];
    _model.jobDesc = dic[@"Write"];
    _sendParamModel.jobDesc =dic[@"Write"];
    [self.tableView reloadData];
}

/**
 *  职位申请回复
 */
- (void)JobReply:(NSNotification *)notofi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notofi.object];
    self.JobReply = dic[@"Reply"];
    _sendParamModel.jobReply = dic[@"replyKey"];
    [self.tableView reloadData];
}

/**
 *  联系方式
 */
- (void)JobPhone:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPhone = dic[@"Phone"];
    _model.contactInfo = dic[@"Phone"];
    _sendParamModel.contactInfo = dic[@"Phone"];
    [self.tableView reloadData];
}

/**
 *  简历接收设置
 */
- (void)JobAccept:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobAccept = dic[@"Accept"];
    _sendParamModel.receiveSet = dic[@"acceptKey"];
    [self.tableView reloadData];
}

/**
 *  4.26 职位发布地点
 */
- (void)JobAddress:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobAddress = dic[@"Address"];
    _model.publishAreaName = dic[@"Address"];
    _sendParamModel.publishAreaId = dic[@"nowLocationKey"];
    [self.tableView reloadData];
}

/**
 *  职位类别
 */
- (void)wzsJobClass:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobClass = dic[@"Name"];
    _model.jobMainType = dic[@"Name"];
    _sendParamModel.jobMainType = dic[@"key"];
    MYLog(@"%@", dic[@"key"]);
    [self.tableView reloadData];
}

/**
 *  工作地址
 */
- (void)wzsJobPlace:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPlace = dic[@"zwjobaddress"];
    _model.jobArea = dic[@"zwjobaddress"];
    _sendParamModel.jobArea = dic[@"zwjobaddress"];
    [self.tableView reloadData];
}

/**
 *  截止时间
 */
- (void)JobDate:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobDate = dic[@"Date"];
    _model.finallyDate = dic[@"Date"];
    _sendParamModel.finallyDate = dic[@"Date"];
    [self.tableView reloadData];
}
// 亮点标签
-(void)getTagStrsFromNotifi:(NSNotification *)notifi{
    NSDictionary *dict = notifi.object;
    _tagStrs = dict[@"str"];
   // MYLog(@"%@",dict[@"key"]);

    _sendParamModel.brightTag = dict[@"key"];
   // MYLog(@"%@",_tagStrs);
      [self.tableView reloadData];
}



- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.tableFooterView = self.BWview;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
//    self.tableView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.tableView];
}

#pragma mark - 保存并发布
- (void)actionYLbutton:(UIButton *)btn
{
    if (!_sendParamModel.personCount) {
        
        _sendParamModel.personCount = _numberFiled.text.intValue;
    }
    MYLog(@"%@",_sendParamModel.mj_keyValues);
    if (_sendParamModel.jobNature && _sendParamModel.jobName && _sendParamModel.jobMainType && _sendParamModel.personCount && _sendParamModel.education && _sendParamModel.experience && _sendParamModel.salary && _sendParamModel.jobDesc && _sendParamModel.publishAreaId && _sendParamModel.finallyDate && _sendParamModel.receiveSet && _sendParamModel.jobReply && _sendParamModel.jobArea && _sendParamModel.contactInfo) {
        
        NSString *url = [baseUrl stringByAppendingString:@"insertJob.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        _sendParamModel.companyId = parameters[@"companyId"];
        _sendParamModel.personCount = _numberFiled.text.intValue;
        _sendParamModel.releaseStatus = @"01";
        MYLog(@"%@",_sendParamModel.mj_keyValues);
        [zyzpHttpTool POST:url parameters: _sendParamModel.mj_keyValues progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@", responseObject);
            if ([responseObject[@"status"] isEqualToString:@"01"]) {
                [self pushAlertViewWithTitle:@"发布职位成功!"];
                [self.navigationController popViewControllerAnimated:YES];
            }else if ([responseObject[@"status"] isEqualToString:@"02"]){
                [self pushAlertViewWithTitle:@"发布职位失败!"];
            }else if ([responseObject[@"status"] isEqualToString:@"500"]){
                [self pushAlertViewWithTitle:@"服务器异常!"];
            }
        } failure:^(NSError *error) {
            MYLog(@"%@",error);
        }];
    } else {
        [self pushAlertViewWithTitle:@"请填写完整的职位信息!!!"];
    }
    
}

#pragma mark - 保存为未发布
- (void)actionBCbutton:(UIButton *)btn
{
    if (!_sendParamModel.personCount) {
        
        _sendParamModel.personCount = _numberFiled.text.intValue;
    }
    if (_sendParamModel.jobNature && _sendParamModel.jobName && _sendParamModel.jobMainType && _sendParamModel.personCount && _sendParamModel.education && _sendParamModel.experience && _sendParamModel.salary && _sendParamModel.jobDesc && _sendParamModel.publishAreaId && _sendParamModel.finallyDate && _sendParamModel.receiveSet && _sendParamModel.jobReply && _sendParamModel.jobArea && _sendParamModel.contactInfo) {
        
        NSString *url = [baseUrl stringByAppendingString:@"insertJob.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        _sendParamModel.companyId = parameters[@"companyId"];
        _sendParamModel.releaseStatus = @"02";
        MYLog(@"%@",_sendParamModel.mj_keyValues);
        [zyzpHttpTool POST:url parameters: _sendParamModel.mj_keyValues progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@", responseObject);
            if ([responseObject[@"status"] isEqualToString:@"01"]) {
                [self pushAlertViewWithTitle:@"保存为未发布成功!"];
                [self.navigationController popViewControllerAnimated:YES];
            }else if ([responseObject[@"status"] isEqualToString:@"02"]){
                [self pushAlertViewWithTitle:@"保存为未发布失败!"];
            }else if ([responseObject[@"status"] isEqualToString:@"500"]){
                [self pushAlertViewWithTitle:@"服务器异常!"];
            }
        } failure:^(NSError *error) {
            MYLog(@"%@",error);
        }];
    } else {
        [self pushAlertViewWithTitle:@"请填写完整的职位信息!!!"];
    }
    
 
}

- (void)actionshuangbutton:(UIButton *)btn
{
    _sendParamModel.personCount = _numberFiled.text.intValue;
    if (_sendParamModel.jobNature && _sendParamModel.jobName && _sendParamModel.jobMainType && _sendParamModel.personCount && _sendParamModel.education && _sendParamModel.experience && _sendParamModel.salary && _sendParamModel.jobDesc && _sendParamModel.publishAreaId && _sendParamModel.finallyDate && _sendParamModel.receiveSet && _sendParamModel.jobReply && _sendParamModel.jobArea && _sendParamModel.contactInfo) {
        
        NSString *url = [baseUrl stringByAppendingString:@"insertJob.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        _sendParamModel.companyId = parameters[@"companyId"];
        _sendParamModel.releaseStatus = @"02";
        MYLog(@"%@",_sendParamModel.mj_keyValues);
        [zyzpHttpTool POST:url parameters: _sendParamModel.mj_keyValues progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@", responseObject);
            if ([responseObject[@"status"] isEqualToString:@"01"]) {
                [self pushAlertViewWithTitle:@"保存为未发布成功!"];
                LCMbeanViewController *lcm = [[LCMbeanViewController alloc] init];
                lcm.shuang = self.shuang;
                [self.navigationController pushViewController:lcm animated:YES];
            }else if ([responseObject[@"status"] isEqualToString:@"02"]){
                [self pushAlertViewWithTitle:@"保存为未发布失败!"];
            }else if ([responseObject[@"status"] isEqualToString:@"500"]){
                [self pushAlertViewWithTitle:@"服务器异常!"];
            }
        } failure:^(NSError *error) {
            MYLog(@"%@",error);
        }];
    } else {
        [self pushAlertViewWithTitle:@"请填写完整的职位信息!!!"];
    }
}

// cell个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.nameArray.count;
}

/**
 *  cell高度
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}

#pragma mark - 解析json数据
- (void)dataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"position" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    _zwlbArray = dic[@"Position"];
    
    // 学历
    NSString *school = [[NSBundle mainBundle] pathForResource:@"education" ofType:@"json"];
    NSData *schooldata = [NSData dataWithContentsOfFile:school];
    _xlArray = [NSJSONSerialization JSONObjectWithData:schooldata options:NSJSONReadingAllowFragments error:nil];
    
    // 经验
    NSString *jypath = [[NSBundle mainBundle] pathForResource:@"workhistory" ofType:@"json"];
    NSData *jydata = [NSData dataWithContentsOfFile:jypath];
    _jyyqArray = [NSJSONSerialization JSONObjectWithData:jydata options:NSJSONReadingAllowFragments error:nil];
    
    // 月薪
    NSString *yxpath = [[NSBundle mainBundle] pathForResource:@"salary" ofType:@"json"];
    NSData *yxdata = [NSData dataWithContentsOfFile:yxpath];
    _zwyxArray = [NSJSONSerialization JSONObjectWithData:yxdata options:NSJSONReadingAllowFragments error:nil];
    
    // 亮点标签
    NSString *ldbqpath = [[NSBundle mainBundle] pathForResource:@"lightpoint" ofType:@"json"];
    NSData *ldbqdata = [NSData dataWithContentsOfFile:ldbqpath];
    _ldbqArray = [NSJSONSerialization JSONObjectWithData:ldbqdata options:NSJSONReadingAllowFragments error:nil];
    
    // 职位申请恢复
    NSString *zwsqhf = [[NSBundle mainBundle] pathForResource:@"applyhuifu" ofType:@"json"];
    NSData *zwsqhfdata = [NSData dataWithContentsOfFile:zwsqhf];
    _zwsqhfArray = [NSJSONSerialization JSONObjectWithData:zwsqhfdata options:NSJSONReadingAllowFragments error:nil];
    
    
    
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    newJobNameViewController *jobName = [[newJobNameViewController alloc] init];
    static NSString *identifier = @"QYjobVC";
    _cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    _cell = [[QYjobTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    
    if (self.ididididid != nil) {
        self.allArray = [NSMutableArray array];
        
        if ([_model.jobNature isEqualToString:@"01"]) {
            _model.jobNature = @"全职招聘";
        } else if ([_model.jobNature isEqualToString:@"02"]) {
            _model.jobNature = @"实习招聘";
        }
        
        if ([_model.receiveSet isEqualToString:@"01"]) {
            _model.receiveSet = @"仅通过指缘系统接收简历";
        } else if ([_model.receiveSet isEqualToString:@"02"]) {
            _model.receiveSet = @"同时转发简历到邮箱";
        }
        
//        for (NSDictionary *dict in _zwlbArray) {
//            if (_model.jobMainType != nil) {
//                if ([[_model.jobMainType substringToIndex:1] isEqualToString:@"0"]) {
//                    if ([dict[@"dicKey"] isEqualToString:[_model.jobMainType substringFromIndex:11]]) {
//                        _model.jobMainType = dict[@"dicValue"];
//                    }
//                }
//            } else {
//                _model.jobMainType = @"";
//            }
//        }
        
        for (NSDictionary *dict in _zwlbArray) {
            if (_model.jobMainType.length > 11) {
                if ([dict[@"dicKey"] isEqualToString:[_model.jobMainType substringFromIndex:11]]) {
                    _model.jobMainType = dict[@"dicValue"];
                }
            } else {
                if ([dict[@"dicKey"] isEqualToString:_model.jobMainType]) {
                    _model.jobMainType = dict[@"dicValue"];
                }
            }
        }
        
        for (NSDictionary *schoolDic in _xlArray) {
            if ([schoolDic[@"dicKey"] isEqualToString:_model.education]) {
                _model.education = schoolDic[@"dicValue"];
            }
        }
        
        for (NSDictionary *jyDic in _jyyqArray) {
            if ([jyDic[@"dicKey"] isEqualToString:_model.experience]) {
                _model.experience = jyDic[@"dicValue"];
            }
        }
        
       
        NSArray *tagArray = [_model.brightTag componentsSeparatedByString:@","];
        for (int i = 0; i < tagArray.count; i++) {
            for (int j = 0; j < _ldbqArray.count; j++) {
                if ([tagArray[i] isEqualToString:_ldbqArray[j][@"dicKey"]]) {
                    NSString *str = _ldbqArray[j][@"dicValue"];
                    [_ldArray addObject:str];
                }
            }
        }
        _model.brightTag = [_ldArray componentsJoinedByString:@","];
        
        for (NSDictionary *yxDic in _zwyxArray) {
            if ([yxDic[@"dicKey"] isEqualToString:_model.salary]) {
                _model.salary = yxDic[@"dicValue"];
            }
        }
        
        for (NSDictionary *zwhfDic in _zwsqhfArray) {
            if ([zwhfDic[@"dicKey"] isEqualToString:_model.jobReply]) {
                _model.jobReply = zwhfDic[@"dicValue"];
            }
        }

        
        
        
        self.allArray = @[_model.jobNature, _model.jobName, _model.jobMainType, [NSString stringWithFormat:@"%ld", _model.personCount], _model.education, _model.experience, _model.salary, _model.jobDesc, _model.brightTag, _model.publishAreaName, _model.finallyDate, _model.receiveSet, _model.jobReply, _model.jobArea, _model.contactInfo];
        _cell.lastLabel.text = self.allArray[indexPath.row];
    } else {
        if (indexPath.row == 0) {
            _cell.lastLabel.text = self.JobNature;
            //        self.model.jobNature = self.JobNature;
        } else if (indexPath.row == 1) {
            // 职位名称
            _cell.lastLabel.text = self.JobName;
        } else if (indexPath.row == 2) {
            // 职位类别
            _cell.lastLabel.text = self.JobClass;
        } else if (indexPath.row == 3) {
            UITextField *numberFiled = [[UITextField alloc] init];
            numberFiled.frame = _cell.lastLabel.frame;
            numberFiled.textAlignment = NSTextAlignmentRight;
            [_cell addSubview:numberFiled];
            numberFiled.keyboardType = UIKeyboardTypeNumberPad;
            if ([appDelegate.appDefault objectForKey:@"number"]) {
                numberFiled.text = [appDelegate.appDefault objectForKey:@"number"];
            }
            
            [numberFiled addTarget:self action:@selector(filedChangeValue:) forControlEvents:UIControlEventEditingChanged];
            _numberFiled = numberFiled;
            //_cell.lastLabel.text = self.JobNumber;
        } else if (indexPath.row == 4) {
            _cell.lastLabel.text = self.JobStudy;
        } else if (indexPath.row == 5) {
            _cell.lastLabel.text = self.JobExp;
        } else if (indexPath.row == 6) {
            _cell.lastLabel.text = self.JobWages;
        } else if (indexPath.row == 7) {
            _cell.lastLabel.text = self.JobWrite;
        } else if (indexPath.row == 8) {
            // 亮点标签
             _cell.lastLabel.text = self.tagStrs;
        } else if (indexPath.row == 9) {
            // 职位发布地点
            _cell.lastLabel.text = self.JobAddress;
        } else if (indexPath.row == 10) {
            // 发布截止日期
            _cell.lastLabel.text = self.JobDate;
        } else if (indexPath.row == 11) {
            // 简历接收设置
            _cell.lastLabel.text = self.JobAccept;
        } else if (indexPath.row == 12) {
            // 职位申请回复
            _cell.lastLabel.text = self.JobReply;
        } else if (indexPath.row == 13) {
            // 工作地址
            _cell.lastLabel.text = self.JobPlace;
        } else if (indexPath.row == 14) {
            // 联系方式
            _cell.lastLabel.text = self.JobPhone;
        }
    }
    _cell.lastLabel.textColor = Color(138, 138, 138);
    _cell.lastLabel.textAlignment = NSTextAlignmentRight;
    _cell.nameLable.textColor = Color(138, 138, 138);
    _cell.nameLable.text = self.nameArray[indexPath.row];
    _cell.imageV.image = [UIImage imageNamed:@"find_go"];
    return _cell;
}

-(BOOL)filedChangeValue:(UITextField *)textFile{
    MYLog(@"%@",textFile.text);
    if ([self isPureNumandCharacters:textFile.text]) {
        
        if ([textFile.text intValue] >= 1000000) {
            [self pushAlertViewWithTitle:@"人数不能太大"];
            textFile.text = nil;
        } else {
            
            [appDelegate.appDefault setObject:textFile.text forKey:@"number"];
            [appDelegate.appDefault synchronize];
        }
    } else {
        [self pushAlertViewWithTitle:@"请输入整数"];
        textFile.text = nil;
    }
    return YES;
}

// 判断字符串是否为纯数字
- (BOOL)isPureNumandCharacters:(NSString *)string
{
    string = [string stringByTrimmingCharactersInSet:
              [NSCharacterSet decimalDigitCharacterSet]];
    if(string.length > 0)
    {
        return NO;
    }
    return YES;
}

/**
 *  cell点击方法
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.hidesBottomBarWhenPushed = YES;
    if (indexPath.row == 0) {
        newJobNatureViewController *newJobNatureVC = [[newJobNatureViewController alloc] init];
        [self.navigationController pushViewController:newJobNatureVC animated:YES];
        
    } else if (indexPath.row == 1) {
        ZWNameVC *jobName = [[ZWNameVC alloc] init];
        jobName.name = _sendParamModel.jobName;
//        jobName.name = _model.jobName;
        [self.navigationController pushViewController:jobName animated:YES];
    } else if (indexPath.row == 2) {
        newJobNameViewController *newJobClass = [[newJobNameViewController alloc] init];
        [self.navigationController pushViewController:newJobClass animated:YES];
    } else if (indexPath.row == 3) {
//        newJobNumberViewController *newJobNumber = [[newJobNumberViewController alloc] init];
        [_numberFiled becomeFirstResponder];
//        [self.navigationController pushViewController:newJobNumber animated:YES];
    } else if (indexPath.row == 4) {
        newJobStudyViewController *newJobStudy = [[newJobStudyViewController alloc] init];
        [self.navigationController pushViewController:newJobStudy animated:YES];
    } else if (indexPath.row == 5) {
        newJobExpViewController *newJobExp = [[newJobExpViewController alloc] init];
        [self.navigationController pushViewController:newJobExp animated:YES];
    } else if (indexPath.row == 6) {
        newJobWagesViewController *newJobWages = [[newJobWagesViewController alloc] init];
        [self.navigationController pushViewController:newJobWages animated:YES];
    } else if (indexPath.row == 7) {
        newJobWriteViewController *newJobWrite = [[newJobWriteViewController alloc] init];
        newJobWrite.describe = _sendParamModel.jobDesc;
        [self.navigationController pushViewController:newJobWrite animated:YES];
    } else if (indexPath.row == 8) {
        newJobTagViewController *newJobTag = [[newJobTagViewController alloc] init];
        [self.navigationController pushViewController:newJobTag animated:YES];
    } else if (indexPath.row == 9) {
        newJobAddressViewController *newJobAddress = [[newJobAddressViewController alloc] init];
        [self.navigationController pushViewController:newJobAddress animated:YES];
    } else if (indexPath.row == 10) {
        newJobDateViewController *newJobDate = [[newJobDateViewController alloc] init];
        [self.navigationController pushViewController:newJobDate animated:YES];
    } else if (indexPath.row == 11) {
        newJobAcceptViewController *newJobAccept = [[newJobAcceptViewController alloc] init];
        [self.navigationController pushViewController:newJobAccept animated:YES];
    } else if (indexPath.row == 12) {
        newJobReplyViewController *newJobReply = [[newJobReplyViewController alloc] init];
        [self.navigationController pushViewController:newJobReply animated:YES];
    } else if (indexPath.row == 13) {
        ZWJobAddressVC *newJobPlace = [[ZWJobAddressVC alloc] init];
        newJobPlace.addre = _sendParamModel.jobArea;
        [self.navigationController pushViewController:newJobPlace animated:YES];
    } else if (indexPath.row == 14) {
        newJobPhoneViewController *newJobPhone = [[newJobPhoneViewController alloc] init];
        newJobPhone.numb = _sendParamModel.contactInfo;
        [self.navigationController pushViewController:newJobPhone animated:YES];
    }
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [_numberFiled resignFirstResponder];
}


- (void)addUIView
{
    
    
    if (![_shuang isEqualToString:@"666"]) {
        // 表尾view
        self.BWview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 150)];
        self.BWview.backgroundColor = [UIColor whiteColor];
        // 预览职位按钮
        UIButton *ylButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        //    ylButton.frame = CGRectMake(23, 30, 158, 44);
        ylButton.x = 23;
        ylButton.y = 30;
        ylButton.width = (screenW - 23 - 23 - 15) / 2;
        ylButton.height = 44;
        
        [ylButton setTitle:@"保存并发布" forState:0];
        ylButton.titleLabel.font = [UIFont fontWithName:@"MicrosoftYaHei" size:18.0];
        [ylButton.layer setCornerRadius:5.0];
        [ylButton setTintColor:[UIColor whiteColor]];
        [ylButton addTarget:self action:@selector(actionYLbutton:) forControlEvents:(UIControlEventTouchUpInside)];
        ylButton.backgroundColor = zyMainColor;
        [self.BWview addSubview:ylButton];
        
        // 保存为未发布按钮
        UIButton *bcButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        //    bcButton.frame = CGRectMake(screenW - 23 - 158, 30, 158, 44);
        bcButton.x = CGRectGetMaxX(ylButton.frame) + 15;
        bcButton.y = ylButton.y;
        bcButton.width = ylButton.width;
        bcButton.height = ylButton.height;
        
        [bcButton setTitle:@"保存为未发布" forState:0];
        bcButton.titleLabel.font = [UIFont fontWithName:@"MicrosoftYaHei" size:18.0];
        [bcButton.layer setCornerRadius:5.0];
        [bcButton setTintColor:[UIColor whiteColor]];
        [bcButton addTarget:self action:@selector(actionBCbutton:) forControlEvents:(UIControlEventTouchUpInside)];
        bcButton.backgroundColor = zyMainColor;
        [self.BWview addSubview:bcButton];
    } else {
        // 表尾view
        self.BWview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 150)];
        self.BWview.backgroundColor = [UIColor whiteColor];
        // 保存为未发布按钮
        UIButton *bcButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        //    bcButton.frame = CGRectMake(screenW - 23 - 158, 30, 158, 44);
        bcButton.x = 100;
        bcButton.y = 30;
        bcButton.width = screenW - 200;
        bcButton.height = 44;
        [bcButton setTitle:@"保存为未发布" forState:0];
        bcButton.titleLabel.font = [UIFont fontWithName:@"MicrosoftYaHei" size:18.0];
        [bcButton.layer setCornerRadius:5.0];
        [bcButton setTintColor:[UIColor whiteColor]];
        [bcButton addTarget:self action:@selector(actionshuangbutton:) forControlEvents:(UIControlEventTouchUpInside)];
        bcButton.backgroundColor = zyMainColor;
        [self.BWview addSubview:bcButton];
    }
}

- (NSString *)dateStringWithDate:(NSDate *)date DateFormat:(NSString *)dateFormat
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"]];
    NSString *str = [dateFormatter stringFromDate:date];
    return str ? str : @"";
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)pushAlertViewWithTitle:(NSString *)title{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:title delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    [NSTimer scheduledTimerWithTimeInterval:2.30f
                                     target:self
                                   selector:@selector(applyPositiTimerFireMethod:)
                                   userInfo:alert
                                    repeats:YES];
    [alert show];
}
- (void)applyPositiTimerFireMethod:(NSTimer*)theTimer//弹出框
{
    UIAlertView *alert = (UIAlertView*)[theTimer userInfo];
    [alert dismissWithClickedButtonIndex:0 animated:NO];
    alert =NULL;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

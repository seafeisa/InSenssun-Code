//
//  QYpositionManageViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/19.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.19新增 管理职位列表
 */

#import "QYpositionManageViewController.h"
#import "QYpositionTableViewCell.h"
#import "Common.h"
#import "DTKDropdownMenuView.h"
#import <MJRefresh/MJRefresh.h>
#import "zyzpHttpTool.h"
#import "Account.h"
#import "QYposition.h"
#import "ChangeJobVC.h"
#import "QYJobViewController.h"
#import "QYchangeJob.h"
#import "otherPostDetailController.h"
#import "UIView+ZYFrame.h"
#import <UIImageView+WebCache.h>
#import "ZWingCell.h"



@interface QYpositionManageViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSString *viewState;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSString *label;

@property (nonatomic, strong) QYposition *model;

@property (nonatomic, assign) NSInteger number;

@property (nonatomic, strong) NSArray *xlarray;

@property (nonatomic, strong) NSArray *jyyqarray;

/**
 *  4.29新增
 */
@property (nonatomic, strong) NSMutableArray *jobIDArray;

@property (nonatomic, strong) NSMutableArray *moreArr;

// 公司id
@property (nonatomic, strong) NSMutableArray *comID;

@end

@implementation QYpositionManageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.title = @"管理职位列表";
    self.tableView.rowHeight = 86;
    self.viewState = @"0";
    self.number = 1;
    [self addSubView];
    [self addMenuView];
    
    
    
    
}

//-(NSMutableArray *)moreArr{
//    if (!_moreArr) {
//        _moreArr = [NSMutableArray array];
//    }
//    return _moreArr;
//}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//    self.moreArr = nil;
    [self dataForJson];
   
}

- (void)getDataForUrll
{
    NSString *url = [baseUrl stringByAppendingString:@"selectJobList.htm"];
    NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
    parameters[@"sb"] = self.viewState;
    parameters[@"page"] = [NSString stringWithFormat:@"%ld", (long)self.number];
    [zyzpHttpTool GET:url parameters:parameters progress:^{
        
    } success:^(id responseObject) {

        self.jobIDArray = [NSMutableArray array];
        self.dataArray = [NSMutableArray array];
        _comID = [NSMutableArray array];
        for (NSDictionary *dic in responseObject) {
            self.model = [[QYposition alloc] init];
            NSString *str  = dic[@"jobId"];
            NSString *companyId = dic[@"companyId"];
            [_model setValuesForKeysWithDictionary:dic];
            [self.dataArray addObject:_model];
            [self.jobIDArray addObject:str];
            [_comID addObject:companyId];
        }
        
//        [self.moreArr addObjectsFromArray:self.dataArray];
        
//        [self setUpFooterView];
        
      
        [self.tableView reloadData];
        
        [self.tableView.mj_header endRefreshing];
    } failure:^(NSError *error) {
        MYLog(@"%@", error);
    }];
}

-(void)pushAlertViewWithTitle:(NSString *)title{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:title delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    [NSTimer scheduledTimerWithTimeInterval:2.30f
                                     target:self
                                   selector:@selector(applyPositiTimerFireMethod:)
                                   userInfo:alert
                                    repeats:YES];
    [alert show];
}
- (void)applyPositiTimerFireMethod:(NSTimer*)theTimer//弹出框
{
    UIAlertView *alert = (UIAlertView*)[theTimer userInfo];
    [alert dismissWithClickedButtonIndex:0 animated:NO];
    alert =NULL;
}


- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(getDataForUrll)];
    [self.tableView.mj_header beginRefreshing];
}

- (void)addMenuView
{
    DTKDropdownItem *item0 = [DTKDropdownItem itemWithTitle:@"发布中的职位" callBack:^(NSUInteger index, id info) {
        _viewState = @"0";
//        self.moreArr = nil;

        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
 
    }];
    DTKDropdownItem *item1 = [DTKDropdownItem itemWithTitle:@"已暂停的职位" callBack:^(NSUInteger index, id info) {
        _viewState = @"1";
//         self.moreArr = nil;
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownItem *item2 = [DTKDropdownItem itemWithTitle:@"未发布的职位" callBack:^(NSUInteger index, id info) {
        _viewState = @"2";
//         self.moreArr = nil;
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownItem *item3 = [DTKDropdownItem itemWithTitle:@"发布结束职位" callBack:^(NSUInteger index, id info) {
        _viewState = @"3";
//         self.moreArr = nil;
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownItem *item4 = [DTKDropdownItem itemWithTitle:@"被冻结的职位" callBack:^(NSUInteger index, id info) {
        _viewState = @"4";

//         self.moreArr = nil;
        [self.tableView.mj_header beginRefreshing];
//        [self getDataForUrl];
    }];
    DTKDropdownMenuView *menuView = [DTKDropdownMenuView dropdownMenuViewForNavbarTitleViewWithFrame:CGRectMake(0, 0, 200.f, 44.f) dropdownItems:@[item0,item1,item2,item3, item4]];
    menuView.currentNav = self.navigationController;
    menuView.dropWidth = screenH / 2 + 64;
    menuView.titleFont = [UIFont systemFontOfSize:18.f];
    menuView.textColor =  ColorWithRGB(102.f, 102.f, 102.f);
    menuView.textFont = [UIFont systemFontOfSize:13.f];
    
    menuView.cellSeparatorColor = [UIColor orangeColor];
    menuView.textFont = [UIFont systemFontOfSize:14.f];
    
    menuView.animationDuration = 0.3f;
    menuView.selectedIndex = 0;
    self.navigationItem.titleView = menuView;
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 86;
}

- (void)dataForJson
{
    // 学历
    NSString *school = [[NSBundle mainBundle] pathForResource:@"education" ofType:@"json"];
    NSData *schooldata = [NSData dataWithContentsOfFile:school];
    _xlarray = [NSJSONSerialization JSONObjectWithData:schooldata options:NSJSONReadingAllowFragments error:nil];
    
    // 经验
    NSString *jypath = [[NSBundle mainBundle] pathForResource:@"workhistory" ofType:@"json"];
    NSData *jydata = [NSData dataWithContentsOfFile:jypath];
    _jyyqarray = [NSJSONSerialization JSONObjectWithData:jydata options:NSJSONReadingAllowFragments error:nil];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    self.model = self.dataArray[indexPath.row];
    ZWingCell *cell = [ZWingCell cellWithTableView:tableView];
    
    for (NSDictionary *xlDic in _xlarray) {
        if ([xlDic[@"dicKey"] isEqualToString:_model.education]) {
            _model.education = xlDic[@"dicValue"];
        }
    }
    
    for (NSDictionary *jyDic in _jyyqarray) {
        if ([jyDic[@"dicKey"] isEqualToString:_model.experience]) {
            _model.experience = jyDic[@"dicValue"];
        }
    }
    
    if ([_model.education isEqualToString:@""]) {
        _model.education = @"不限";
        if ([_model.experience isEqualToString:@""]) {
            _model.experience = @"不限";
            self.label = [NSString stringWithFormat:@"%@ / %@ / %@", _model.publishAreaName, _model.education, _model.experience];
        } else {
            self.label = [NSString stringWithFormat:@"%@ / %@ / %@", _model.publishAreaName, _model.education, _model.experience];
        }
    } else {
        if ([_model.experience isEqualToString:@""]) {
            _model.experience = @"不限";
            self.label = [NSString stringWithFormat:@"%@ / %@ / %@", _model.publishAreaName, _model.education, _model.experience];
        } else {
            self.label = [NSString stringWithFormat:@"%@ / %@ / %@", _model.publishAreaName, _model.education, _model.experience];
        }
    }
    
    [cell.topImageView sd_setImageWithURL:[NSURL URLWithString:_conLogo]];
    
    cell.addressLabel.text = self.label;
    
    cell.nameLable.text = _model.jobName;
    
    cell.dateLabel.text = _model.finallyDate;
    
    cell.numberLabel.text = [NSString stringWithFormat:@"%@", _model.countResumeNum];
    
    return cell;
}

- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_viewState isEqualToString:@"0"]) {
        UITableViewRowAction *deleteRowAction = [UITableViewRowAction rowActionWithStyle:(UITableViewRowActionStyleDestructive) title:@"刷新" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"updateJobPublishDate.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];

                [self.tableView reloadData];
            } failure:^(NSError *error) {
            }];
            [self.tableView reloadData];
        }];
        UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"暂停" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"updateJobClose.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                [self.tableView reloadData];

            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
            [self.tableView.mj_header beginRefreshing];
        }];
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"修改" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            
            
            NSString *url = [baseUrl stringByAppendingString:@"selectJobEdit.htm"];
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            param[@"jobId"] = self.jobIDArray[indexPath.row];
           
            [zyzpHttpTool GET:url parameters:param progress:^{
                
            } success:^(id responseObject) {
               
                NSDictionary *dic = responseObject[0];
                QYchangeJob *model = [[QYchangeJob alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                QYJobViewController *changeVC = [[QYJobViewController alloc] init];
                changeVC.model = model;
                changeVC.ididididid = self.jobIDArray[indexPath.row];
                [self.navigationController pushViewController:changeVC animated:YES];
                [self.tableView reloadData];
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
            [self.tableView reloadData];
        }];
//        [self.tableView reloadData];
        deleteRowAction.backgroundColor = Color(255, 178, 0);
        editRowAction.backgroundColor = Color(94, 163, 118);
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[deleteRowAction, editRowAction, beginRowAction];
    } else if ([_viewState isEqualToString:@"1"]){
        
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"恢复" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"updateJobOpen.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{   
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
                [self.tableView reloadData];
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
        }];
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[beginRowAction];
    } else if ([_viewState isEqualToString:@"2"]) {
        UITableViewRowAction *deleteRowAction = [UITableViewRowAction rowActionWithStyle:(UITableViewRowActionStyleDestructive) title:@"删除" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            NSString *url = [baseUrl stringByAppendingString:@"deleteUnpublishedJob.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
//                [self getDataForUrl];
                
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];
            
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
            
        }];
        
        UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"发布" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            
            
            NSString *url = [baseUrl stringByAppendingString:@"releaseJob.htm"];
            NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
            parameters[@"jobIds"] = self.jobIDArray[indexPath.row];
            
            
            [zyzpHttpTool GET:url parameters:parameters progress:^{
                
            } success:^(id responseObject) {
                
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                
                [alertView show];
                
//                [self getDataForUrl];
                [self.tableView reloadData];
                
                
            } failure:^(NSError *error) {
                
            }];
//            [self.tableView reloadData];
            [self.tableView.mj_header beginRefreshing];
            
            
        }];
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"修改" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            
            
            NSString *url = [baseUrl stringByAppendingString:@"selectJobEdit.htm"];
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            param[@"jobId"] = self.jobIDArray[indexPath.row];
            
            [zyzpHttpTool GET:url parameters:param progress:^{
                
            } success:^(id responseObject) {
                
                NSDictionary *dic = responseObject[0];
                QYchangeJob *model = [[QYchangeJob alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                QYJobViewController *changeVC = [[QYJobViewController alloc] init];
                changeVC.model = model;
                changeVC.ididididid = self.jobIDArray[indexPath.row];
                [self.navigationController pushViewController:changeVC animated:YES];
                [self.tableView reloadData];
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
            [self.tableView reloadData];
        
        }];
        deleteRowAction.backgroundColor = Color(255, 178, 0);
        editRowAction.backgroundColor = Color(94, 163, 118);
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[deleteRowAction, editRowAction, beginRowAction];
    } else if ([_viewState isEqualToString:@"3"]) {
        UITableViewRowAction *beginRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"修改" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            NSString *url = [baseUrl stringByAppendingString:@"selectJobEdit.htm"];
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            param[@"jobId"] = self.jobIDArray[indexPath.row];
            MYLog(@"%@", self.jobIDArray[indexPath.row]);
            [zyzpHttpTool GET:url parameters:param progress:^{
                
            } success:^(id responseObject) {
                MYLog(@"%@", responseObject);
                NSDictionary *dic = responseObject[0];
                QYchangeJob *model = [[QYchangeJob alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                QYJobViewController *changeVC = [[QYJobViewController alloc] init];
                changeVC.model = model;
                changeVC.ididididid = self.jobIDArray[indexPath.row];
                [self.navigationController pushViewController:changeVC animated:YES];
                
                [self.tableView reloadData];
            } failure:^(NSError *error) {
                MYLog(@"%@", error);
            }];
            [self.tableView reloadData];
        }];
        beginRowAction.backgroundColor = Color(144, 209, 167);
        return @[beginRowAction];
    }
    return nil;
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
//     self.model = self.moreArr[indexPath.row];
    otherPostDetailController *postDetailC =[otherPostDetailController new];
    postDetailC.jobId = _jobIDArray[indexPath.row];
    postDetailC.companyId = _comID[indexPath.row];
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:postDetailC animated:YES];
    
}

-(void)setUpFooterView{
    UIView *footerView =[[UIView alloc] init];
    footerView.x = 0;
    footerView.y = screenH - 64;
    footerView.height = 64;
    footerView.width = screenW;
    
    UIButton *moreDataBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    moreDataBtn.width = screenW - 48;
    moreDataBtn.height = 44;
    moreDataBtn.x = 24;
    moreDataBtn.layer.cornerRadius = 10;
    moreDataBtn.y = (footerView.height - moreDataBtn.height)/2;
    [moreDataBtn setTitle:@"加载更多" forState:UIControlStateNormal];
    moreDataBtn.backgroundColor = zyMainColor;
    [moreDataBtn addTarget:self action:@selector(moreDataBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:moreDataBtn];
//    if (self.moreArr.count >= 20) {
//        self.tableView.tableFooterView = footerView;
//    }
   self.tableView.tableFooterView = footerView;
}
-(void)moreDataBtnClick{
    
    self.number ++;
    [self getDataForUrll];
   
    if (self.dataArray.count < 20) {
        
        [self pushAlertViewWithTitle:@"没有更多数据"];
    }
    
}


@end

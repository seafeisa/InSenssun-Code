//
//  GRscoreVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/23.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "GRscoreVC.h"
#import "Common.h"
#import "zyzpHttpTool.h"
#import "Account.h"
#import "UIView+ZYFrame.h"
#import "zyNavigationItemTool.h"
#import "interviewViewController.h"



@interface GRscoreVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSString *score;

@property (nonatomic, strong) NSString *paperName;

/**
 *  面试评语
 */
@property (nonatomic, strong) NSString *talk;

/**
 *  专家点评
 */
@property (nonatomic, strong) NSString *oldMan;

@end

@implementation GRscoreVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.titleName;
    [self addLeftBarBtn];
    [self getDataForUrl];
    
    [zyNavigationItemTool setUpLeftBtnWithTarget:self action:@selector(actionLeft) iamge:nil Title:@"0.0"];
}



- (void)getDataForUrl
{
        self.score = _responseObject[@"score"];
        self.talk = _responseObject[@"evaluateContent"];
        self.oldMan = _responseObject[@"expertComments"];
        [self.tableView reloadData];
    
    [self addSubView];

}




- (void)addSubView
{

    UIView *view = [[UIView alloc] initWithFrame:self.view.bounds];
    
    UILabel *lable1 = [[UILabel alloc] init];
    lable1.font = [UIFont systemFontOfSize:30];
    lable1.textColor = zyMainColor;
    lable1.text = @"恭喜您已完成面试";

    [view addSubview:lable1];
    
    UILabel *label2 = [[UILabel alloc] init];
    label2.text = [NSString stringWithFormat:@"面试成绩:%@",self.score];

    [view addSubview:label2];
    
    
    UILabel *label3 = [[UILabel alloc] init];
    label3.text = @"面试评语:";
    [view addSubview:label3];
    
    UILabel *label4 = [[UILabel alloc] init];
    label4.text = self.talk;

    label4.numberOfLines = 0;
    label4.textColor = Color(100, 100, 100);

    [view addSubview:label4];
    
    UILabel *label5 = [[UILabel alloc] init];
    label5.text = @"专家建议:";
    [view addSubview:label5];
    
    UILabel *label6 = [[UILabel alloc] init];
    label6.text = self.oldMan;

    label6.numberOfLines = 0;
    label6.textColor = Color(100, 100, 100);

    [view addSubview:label6];
    
    
    lable1.x = 10;
    lable1.y = 10;
    [lable1 sizeToFit];
    
    label2.x = lable1.x;
    label2.y = CGRectGetMaxY(lable1.frame) + 5;
    [label2 sizeToFit];
    
    label3.x = label2.x;
    label3.y = CGRectGetMaxY(label2.frame) + 5;
    [label3 sizeToFit];
    
    label4.x = label3.x;
    label4.y = CGRectGetMaxY(label3.frame) + 5;


    label4.width = screenW - 20;

    [label4 sizeToFit];
    
    label5.x = label4.x;
    label5.y = CGRectGetMaxY(label4.frame) + 5;
    [label5 sizeToFit];
    
    label6.x = label5.x;
    label6.y = CGRectGetMaxY(label5.frame) + 5;
    label6.width = screenW - 20;
    [label6 sizeToFit];
    
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableHeaderView = view;
    [self.view addSubview:self.tableView];

}

- (void)actionLeft
{
    [self.navigationController popToViewController:[interviewViewController new] animated:YES];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 0;
}

- (void)addLeftBarBtn
{
    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"nav_back"] style:UIBarButtonItemStylePlain target:self action:@selector(actionMSLeftBtn)];
    self.navigationItem.leftBarButtonItem = leftBtn;
}

- (void)actionMSLeftBtn
{
    for (UIViewController *controller in self.navigationController.viewControllers) {
        if ([controller isKindOfClass:[interviewViewController class]]) {
            interviewViewController *interview = (interviewViewController *)controller;
            [self.navigationController popToViewController:interview animated:YES];
        }
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"GRscoreVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    return cell;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

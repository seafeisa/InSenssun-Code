//
//  interviewVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  模拟面试详情页面

#import "interviewVC.h"
#import "Common.h"
#import "UIView+ZYFrame.h"
#import "zyzpHttpTool.h"
#import "Account.h"
#import "interviewCell.h"
#import "NSString+StringSize.h"
#import "GRscoreVC.h"

@interface interviewVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

// 外围array
@property (nonatomic, strong) NSMutableArray *bigArray;

// 内部array
@property (nonatomic, strong) NSMutableArray *smArray;


@property (nonatomic, assign) NSInteger number;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *dataArray;

/**
 *  4.21晚 新增namelabel
 */
@property (nonatomic, strong) UILabel *nameLabel;

@property (nonatomic, strong) NSMutableArray *numArray;

/**
 *  4.22新增 questionOrders
 */
@property (nonatomic, strong) UILabel *questionOrdersLabel;

@property (nonatomic, strong) NSMutableArray *paperTypeArray;


/**
 *  4.23新增
 */
@property (nonatomic, assign) NSInteger numberI;

@property (nonatomic, strong) NSString *answer;

@property (nonatomic, assign) NSInteger indexRow;

@property (nonatomic, strong) NSMutableArray *anwserArray;

@property (nonatomic, strong) NSIndexPath *path;
/**
 *  5.02新增
 */

@property (nonatomic) BOOL isCell;

@property (nonatomic, strong) NSMutableArray *arry;

/**
 *  多选或者单选
 */
@property (nonatomic, strong) NSMutableArray *typeArray;

@property (nonatomic, strong) NSArray *array;

@property (nonatomic, strong) NSMutableArray *textArray;

/**
 *  答案编号
 */
@property (nonatomic, strong) NSMutableArray *numberIDArray;


@end

@implementation interviewVC

- (void)viewWillAppear:(BOOL)animated
{
    [self getDataForUrl];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.translucent = YES;
    self.number = 0;
    [self addSubView];
    self.indexRow = -1;
    self.tableView.rowHeight = 70;
    self.anwserArray = [NSMutableArray array];
    self.textArray = [NSMutableArray array];
    self.title = self.name;
    [self addButton];
    [self addSubViews];
    
//    [self.tableView registerClass:[interviewCell class] forCellReuseIdentifier:@"interviewVC"];
    
    
//    [self.tableView setEditing:YES animated:YES];
    //    [self actionButton:nil];
}

- (void)getDataForUrl
{
    
            MYLog(@"%@", _responseObject);
            
            self.paperTypeArray = [NSMutableArray array];
            self.nameArray = [NSMutableArray array];
            self.numArray = [NSMutableArray array];
            self.typeArray = [NSMutableArray array];
            self.numberIDArray = [NSMutableArray array];
            self.bigArray = _responseObject;
            for (NSDictionary *dic in self.bigArray) {
                NSString *str = dic[@"questionName"];
                NSString *num = dic[@"questionOrders"];
                NSString *paperType = dic[@"paperType"];
                NSString *ytpe = dic[@"singleMulti"];
                
                [self.nameArray addObject:str];
                [self.numArray addObject:num];
                [self.paperTypeArray addObject:paperType];
                [self.typeArray addObject:ytpe];
                
            }
//            MYLog(@"%@............", self.nameArray);
//            MYLog(@"%@", self.numArray);
            self.nameLabel.text = self.nameArray[0];
            self.questionOrdersLabel.text = self.numArray[0];
            self.smArray = self.bigArray[self.number][@"solutionList"];
            self.dataArray = [NSMutableArray array];
            for (NSDictionary *dic1 in self.smArray) {
                NSString *numID = dic1[@"solutionId"];
                NSString *str = dic1[@"solutionName"];
                [self.dataArray addObject:str];
                [self.numberIDArray addObject:numID];
            }
            
            [self.tableView reloadData];
            
            
            
    
}
- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStyleGrouped)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSString *str = self.dataArray[indexPath.row];
//    
//    CGSize cellSize = [str sizeWithFont:[UIFont systemFontOfSize:14.0] With:screenW - 60];
    
    return 70;
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    interviewCell *cell = [interviewCell cellWithTableView:tableView];
    
    

    cell.tmLabel.text = self.dataArray[indexPath.row];
//    cell.tmLabel.highlightedTextColor = zyMainColor;
    
    return cell;
}


/**
 *  表尾
 */
- (void)addButton
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 50)];
    self.tableView.tableFooterView = view;
    
    UIButton *button = [UIButton buttonWithType:0];
    button.x = 23;
    button.y = 6;
    button.width = screenW - 46;
    button.height = 44;
    [button.layer setCornerRadius:5.0];
    [button setTitle:@"下一题" forState:(UIControlStateNormal)];
    button.backgroundColor = zyMainColor;
    [button addTarget:self action:@selector(actionButton:) forControlEvents:(UIControlEventTouchUpInside)];
    [view addSubview:button];
}

/**
 *  表头
 */
- (void)addSubViews
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 70)];
//    view.backgroundColor = [UIColor yellowColor];
    self.tableView.tableHeaderView = view;
    
    self.questionOrdersLabel = [[UILabel alloc] init];
    _questionOrdersLabel.x = 25;
    _questionOrdersLabel.y = 32;
    _questionOrdersLabel.font = [UIFont systemFontOfSize:15.0];
    _questionOrdersLabel.textColor = Color(80, 80, 80);
    _questionOrdersLabel.width = 20;
    _questionOrdersLabel.height = 15;
    [view addSubview:_questionOrdersLabel];
    
    self.nameLabel = [[UILabel alloc] init];
    _nameLabel.x = CGRectGetMaxX(_questionOrdersLabel.frame) + 5;
    _nameLabel.y = 20;
    _nameLabel.width = screenW - CGRectGetMaxX(_questionOrdersLabel.frame) - 20;
    _nameLabel.height = 40;
    _nameLabel.textColor = Color(80, 80, 80);
    _nameLabel.font = [UIFont systemFontOfSize:15.0];
    _nameLabel.numberOfLines = 0;
    [view addSubview:_nameLabel];
    
}

- (void)actionButton:(UIButton *)button
{
    if ([self.typeArray[_number] isEqualToString:@"01"]) {
        if (self.indexRow != -1) {
            if ([button.titleLabel.text isEqualToString:@"完成"]) {

                [self.anwserArray addObject:self.answer];
                //  回答系统模拟试卷
                NSString *string = [self.anwserArray componentsJoinedByString:@","];
                MYLog(@"%@", string);
                NSString *str = [baseUrl stringByAppendingString:@"toCheckSystemInterviewResult.htm"];
                NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
                parameters[@"answer"] = string;
                parameters[@"paperType"] = self.per;
                
                
                [zyzpHttpTool GET:str parameters:parameters progress:^{
                    
                } success:^(id responseObject) {

                    [self.tableView reloadData];
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alertView show];
                    
                    NSString *url = [baseUrl stringByAppendingString:@"toSystemInterviewByType.htm"];
                    NSMutableDictionary *para = [[Account currentAccount] requestParams];
                    para[@"paperType"] = self.per;
                    
                    [zyzpHttpTool GET:url parameters:para progress:^{
                        
                    } success:^(id response) {
                        
                        GRscoreVC *GRscore = [[GRscoreVC alloc] init];
                        GRscore.typeId = self.per;
                        GRscore.titleName = self.name;
                        GRscore.responseObject = response;
                        [self.navigationController pushViewController:GRscore animated:YES];
                        
                    } failure:^(NSError *error) {
                        
                    }];
                    
                    GRscoreVC *GRscore = [[GRscoreVC alloc] init];
                    GRscore.typeId = self.per;
                    GRscore.titleName = self.name;
                    [self.navigationController pushViewController:GRscore animated:YES];
                    
                    
                } failure:^(NSError *error) {
                    MYLog(@"%@", error);
                }];

            } else if (_number < self.bigArray.count) {
                _number++;
                self.nameLabel.text = self.nameArray[self.number];
                self.questionOrdersLabel.text = self.numArray[self.number];
                self.smArray = self.bigArray[self.number][@"solutionList"];
                MYLog(@"%ld", (unsigned long)self.smArray.count);
                self.dataArray = [NSMutableArray array];
                self.numberIDArray = [NSMutableArray array];
                for (NSDictionary *dic1 in self.smArray) {
                    NSString *num = dic1[@"solutionId"];
                    NSString *str = dic1[@"solutionName"];
                    [self.dataArray addObject:str];
                    [self.numberIDArray addObject:num];
                }
                [self.tableView reloadData];
                MYLog(@"1");
                MYLog(@"%ld", (long)self.number);
                if (_number == self.bigArray.count - 1) {
                    [button setTitle:@"完成" forState:(UIControlStateNormal)];
                }
                [self.anwserArray addObject:self.answer];
                self.indexRow = -1;
                [self.tableView deselectRowAtIndexPath:self.path animated:NO];
                self.answer = nil;
                
            }
        } else {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请选择答案!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
    } else {
        if (self.textArray.count >= 2) {
            if ([button.titleLabel.text isEqualToString:@"完成"]) {
                for (NSString *str in self.textArray) {
                    [self.anwserArray addObject:str];
                }
                NSString *string = [self.anwserArray componentsJoinedByString:@","];
                MYLog(@"%@", string);
                NSString *str = [baseUrl stringByAppendingString:@"toCheckSystemInterviewResult.htm"];
                NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
                parameters[@"answer"] = string;
                parameters[@"paperType"] = self.per;
                NSLog(@">>>>>>>>>%@",parameters);
                
                [zyzpHttpTool GET:str parameters:parameters progress:^{
                    
                } success:^(id responseObject) {
                    
                    [self.tableView reloadData];
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:responseObject[@"message"] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alertView show];
                    
                    NSString *url = [baseUrl stringByAppendingString:@"toSystemInterviewByType.htm"];
                    NSMutableDictionary *para = [[Account currentAccount] requestParams];
                    para[@"paperType"] = self.per;
                    
                    [zyzpHttpTool GET:url parameters:para progress:^{
                        
                    } success:^(id response) {
                        
                        GRscoreVC *GRscore = [[GRscoreVC alloc] init];
                        GRscore.typeId = self.per;
                        GRscore.titleName = self.name;
                        GRscore.responseObject = response;
                        [self.navigationController pushViewController:GRscore animated:YES];
                        
                    } failure:^(NSError *error) {
                        
                    }];
                    
                    
                    
                    
                } failure:^(NSError *error) {
                    MYLog(@"%@", error);
                }];

            } else if (_number < self.bigArray.count) {
                _number++;
                self.nameLabel.text = self.nameArray[self.number];
                self.questionOrdersLabel.text = self.numArray[self.number];
                self.smArray = self.bigArray[self.number][@"solutionList"];
                MYLog(@"%ld", (unsigned long)self.smArray.count);
                self.dataArray = [NSMutableArray array];
                self.numberIDArray = [NSMutableArray array];
                for (NSDictionary *dic1 in self.smArray) {
                    NSString *num = dic1[@"solutionId"];
                    NSString *str = dic1[@"solutionName"];
                    [self.dataArray addObject:str];
                    [self.numberIDArray addObject:num];

                }
                [self.tableView reloadData];
                MYLog(@"1");
                MYLog(@"%ld", (long)self.number);
                if (_number == self.bigArray.count - 1) {
                    [button setTitle:@"完成" forState:(UIControlStateNormal)];
                }
                for (NSString *str in self.textArray) {
                    [self.anwserArray addObject:str];
                }
                self.indexRow = -1;
                [self.tableView deselectRowAtIndexPath:self.path animated:NO];
                self.answer = nil;
                self.textArray = [NSMutableArray array];
            }
            
        } else {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该题为多选!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            return;
        }
    }
    
    
    self.array = self.tableView.visibleCells;
    [self.array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        interviewCell * objCell = obj;
            
            [objCell setSele:NO];
        
    }];
    
    _isCell = YES;
    _arry = [NSMutableArray array];
//    MYLog(@"%@", self.paperTypeArray[_number]);
//    MYLog(@"%@", self.answer);
//    MYLog(@"%ld", self.indexRow);
    MYLog(@"%@", self.anwserArray);
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

//    self.indexRow = indexPath.row;
//    self.path = indexPath;
//    self.answer = self.dataArray[indexPath.row];
    
//    MYLog(@"%ld", (long)indexPath.row);
//    MYLog(@"%@", self.path);
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"type"] = self.typeArray[_number];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"typeName" object:dic];
    
    if ([self.typeArray[_number] isEqualToString:@"02"]) {
        _isCell = YES;
        NSNumber *index = [NSNumber numberWithInteger:indexPath.row];
        
        interviewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [self.arry enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj == index) {
                _isCell = NO;
                [self.textArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([obj isEqualToString:self.numberIDArray[indexPath.row]]) {
                        [self.textArray removeObject:self.numberIDArray[indexPath.row]];
                        *stop=TRUE;
                    }
                }];
                *stop=TRUE;
            }else{
                _isCell = YES;

            }
        }];
        if (_isCell) {
            [cell setSele:YES];
            [_arry addObject:index];
            self.answer = self.numberIDArray[indexPath.row];
            
            [self.textArray addObject:self.answer];
        }else{
            [cell setSele:NO];
            [_arry removeObject:index];
            _isCell = YES;
//            self.indexRow = -1;
        }
        
    } else {
        interviewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        self.array = tableView.visibleCells;
        [self.array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            interviewCell * objCell = obj;
            
            if (cell == objCell) {
                self.indexRow = indexPath.row;
                self.path = indexPath;
                self.answer = self.numberIDArray[indexPath.row];

                [objCell setSele:YES];
            }else{
                
                [objCell setSele:NO];
            }
        }];
    }
    MYLog(@"%@", self.numberIDArray);
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  publishViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/3/31.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  找人才--发布兼职

#import "publishViewController.h"
#import "Common.h"
#import "QYpublishTableViewCell.h"
#import "UIView+ZYFrame.h"
#import "newJobNumberViewController.h"
#import "newJobNameViewController.h"
#import "newJobAddressViewController.h"
#import "newJobNatureViewController.h"
#import "JJobMoneyVC.h"
#import "newJobClassViewController.h"
#import "newJobPhoneViewController.h"
#import "newJobPlaceViewController.h"
#import "newJobWagesViewController.h"
#import "newJobWriteViewController.h"
#import "JJobPeopleNameVC.h"
#import "WZSEmailViewController.h"
#import "newJobDateViewController.h"
#import "JJobEndDateVC.h"
#import "sendPTModel.h"
#import "Account.h"
#import "zyzpHttpTool.h"
#import "AppDelegate.h"
#import <MJExtension.h>
#import "partTimeDateController.h"
#import "ZWNameVC.h"
#import "JZMoneyVC.h"
#import "ZWJobAddressVC.h"
#import "LoadDataPartTimeVC.h"

@interface publishViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *array;

@property (nonatomic, strong) UIView *bwView;

@property (nonatomic, strong) UITextField *numberFiled;

@property (nonatomic, strong) NSString *JobNumber;
/**
 *  发布兼职所需参数的模型
 */
@property (nonatomic, strong) sendPTModel *sendPartTimeModel;

/**
 *  4.28新增
 */
@property (nonatomic, strong) NSString *JobName;

@property (nonatomic, strong) NSString *JobClass;

@property (nonatomic, strong) NSString *JobWages;

@property (nonatomic, strong) NSString *JobWrite;

@property (nonatomic, strong) NSString *JobAddress;

@property (nonatomic, strong) NSString *JobPlace;

@property (nonatomic, strong) NSString *JobPhone;

@property (nonatomic, strong) NSString *JJobMoney;

/**
 *  4.29新增
 */
@property (nonatomic, strong) NSString *JJobPeopleName;

@property (nonatomic, strong) NSString *EmailVC;

/**
 *  5.02新增
 */
@property (nonatomic, strong) NSString *JobDate;

@property (nonatomic, strong) NSString *JobEndDate;



@end

@implementation publishViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 4.15 新增 title
    self.title = @"发布兼职";
    _sendPartTimeModel = [[sendPTModel alloc] init];
    [self notification];

    [self addBwView];
    [self addSubView];
}

- (void)notification {
     // 招聘人数
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobNumber:) name:@"JobNumber" object:nil];
    // 职位名称
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobName:) name:@"ZWname" object:nil];
    // 职位类别
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobClass:) name:@"JobName" object:nil];
    // 职位月薪
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWages:) name:@"JZMONEY" object:nil];
    // 职位描述
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWrite:) name:@"JobWrite" object:nil];
    // 职位发布地点
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobAddress:) name:@"JobAddress" object:nil];
    // 工作地址
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobPlace:) name:@"ZWJOB" object:nil];
    // 联系方式
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobPhone:) name:@"JobPhone" object:nil];
    // 薪资结算
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JJobMoney:) name:@"JJobMoney" object:nil];
    // 联系人
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JJobPeopleName:) name:@"JJobPeopleName" object:nil];
    // 简历接收邮箱
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(EmailVC:) name:@"EmailVC" object:nil];
    //开始时间
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobDate:) name:@"JobDate" object:nil];
    // 结束时间
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobEndDate:) name:@"JobEndDate" object:nil];
    // 兼职时间
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(partTimeDate:) name:@"partTimeDateNotifi" object:nil];
}

-(void)partTimeDate:(NSNotification *)notifi{
    _sendPartTimeModel.partTime = notifi.object;
    [self.tableView reloadData];
}


/**
 *  招聘人数
 */

- (void)JobNumber:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobNumber = dic[@"Number"];
    _model.personCount = (NSInteger)dic[@"Number"];
    _sendPartTimeModel.personCount = [_numberFiled.text intValue];
    [self.tableView reloadData];
}

/**
 *  职位名称
 */
- (void)JobName:(NSNotification *)notifi{
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobName = dic[@"zwname"];
    _model.jobName = dic[@"zwname"];
    _sendPartTimeModel.jobName = dic[@"zwname"];
    [self.tableView reloadData];
}

/**
 *  职位类别
 */
- (void)JobClass:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobClass = dic[@"Name"];
    _model.jobMainType = dic[@"Name"];
    _sendPartTimeModel.jobMainType = dic[@"key"];
    [self.tableView reloadData];
}

/**
 *  职位月薪
 */
- (void)JobWages:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWages = dic[@"jzmoney"];
    
    _sendPartTimeModel.salary = dic[@"jzmoney"];
    [self.tableView reloadData];
}

/**
 *  职位描述
 */
- (void)JobWrite:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWrite = dic[@"Write"];
    _model.jobDesc = dic[@"Write"];
    _sendPartTimeModel.jobDesc = dic[@"Write"];
    [self.tableView reloadData];
}

/**
 *  职位发布地点
 */
- (void)JobAddress:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobAddress = dic[@"Address"];
    _model.jobAreaName = dic[@"Address"];
    _sendPartTimeModel.jobArea = dic[@"nowLocationKey"];
    [self.tableView reloadData];
}

/**
 *  工作地址
 */
- (void)JobPlace:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPlace = dic[@"zwjobaddress"];
     _model.jobAddress = dic[@"zwjobaddress"];
    _sendPartTimeModel.jobAddress = dic[@"zwjobaddress"];
    [self.tableView reloadData];
}

/**
 *  联系方式
 */
- (void)JobPhone:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPhone = dic[@"Phone"];
    _model.linkmanPhone = dic[@"Phone"];
    _sendPartTimeModel.linkmanPhone = dic[@"Phone"];
    [self.tableView reloadData];
}

/**
 *  薪资结算
 */
- (void)JJobMoney:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JJobMoney = dic[@"JobMoney"];
    _model.salaryPay = dic[@"JobMoney"];
    _sendPartTimeModel.salaryPay = dic[@"salaryPayKey"];
    [self.tableView reloadData];
}

/**
 *  联系人
 */
- (void)JJobPeopleName:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JJobPeopleName = dic[@"PeopleName"];
    _model.linkman = dic[@"PeopleName"];
    _sendPartTimeModel.linkman = dic[@"PeopleName"];
    [self.tableView reloadData];
}

/**
 *  简历接收邮箱
 */
- (void)EmailVC:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.EmailVC =  dic[@"Email"];
    _model.receiveEmail = dic[@"Email"];
    _sendPartTimeModel.receiveEmail = dic[@"Email"];
    [self.tableView reloadData];
}

/**
 *  开始时间
 */
- (void)JobDate:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobDate = dic[@"Date"];
    _model.partTimeBeginStr = dic[@"Date"];
    _sendPartTimeModel.partTimeBegin = dic[@"Date"];
    [self.tableView reloadData];
}

/**
 *  结束时间
 */
- (void)JobEndDate:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobEndDate = dic[@"Date"];
    _model.partTimeEndStr = dic[@"Date"];
    _sendPartTimeModel.partTimeEnd = dic[@"Date"];
    [self.tableView reloadData];
}


// 新增
- (void)addBwView
{
    // 4.15 改动frame
    self.bwView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 150)];
    UIButton *button = [UIButton buttonWithType:0];
//    button.frame = CGRectMake(20, 80, screenW - 40, 50);
    button.x = 23;
    button.y = 30;
    button.width = (screenW - 23 - 23 - 15) / 2;
    button.height = 44;
    
    [button.layer setCornerRadius:5.0];
    [button setTitle:@"发布兼职" forState:(UIControlStateNormal)];
    button.backgroundColor = zyMainColor;
    [button addTarget:self action:@selector(actionButton:) forControlEvents:(UIControlEventTouchUpInside)];
    
    UIButton *button1 = [UIButton buttonWithType:0];
//    button1.frame = CGRectMake(20, 150, screenW - 40, 50);
    button1.x = CGRectGetMaxX(button.frame) + 15;
    button1.y = 30;
    button1.width = button.width;
    button1.height = button.height;
    
    [button1.layer setCornerRadius:5.0];
    [button1 setTitle:@"保存为未发布" forState:(UIControlStateNormal)];
    button1.backgroundColor = zyMainColor;

    [button1 addTarget:self action:@selector(actionButtonone:) forControlEvents:(UIControlEventTouchUpInside)];
    
    
    
    [self.bwView addSubview:button];
    [self.bwView addSubview:button1];
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.array = @[@"职位名称", @"职位类别", @"招聘人数", @"兼职时间", @"薪资水平", @"薪资结算", @"开始日期", @"结束日期", @"职位描述", @"职位发布地点", @"工作地址", @"联系人", @"联系电话", @"简历接收邮箱"];
    self.tableView.tableFooterView = self.bwView;
    [self.view addSubview:self.tableView];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 43;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *identifier = @"publishVC";
    QYpublishTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell = [[QYpublishTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    
    if (self.idididid != nil) {
//        if (_model.partTime != nil) {
//            _model.partTime = @"已选择";
//        }
        NSArray *arr = @[_model.jobName, _model.jobMainType, [NSString stringWithFormat:@"%ld", (long)_model.personCount], _model.partTime, [NSString stringWithFormat:@"%ld", (long)_model.salary], _model.salaryPay, _model.partTimeBeginStr, _model.partTimeEndStr, _model.jobDesc, _model.jobAreaName, _model.jobAddress, _model.linkman, _model.linkmanPhone, _model.receiveEmail];
        cell.lastLabel.text = arr[indexPath.row];
    } else {
        if (indexPath.row == 0) {
            cell.lastLabel.text = self.JobName;
        } else if (indexPath.row == 1) {
            cell.lastLabel.text = self.JobClass;
        } else if (indexPath.row == 2) {
            //cell.lastLabel.text = self.JobNumber;
            UITextField *numberFiled = [[UITextField alloc] init];
            numberFiled.frame = cell.lastLabel.frame;
            numberFiled.textAlignment = NSTextAlignmentRight;
            [cell addSubview:numberFiled];
            numberFiled.keyboardType = UIKeyboardTypeNumberPad;
            if ([appDelegate.appDefault objectForKey:@"number"]) {
                numberFiled.text = [appDelegate.appDefault objectForKey:@"number"];
            }
            [numberFiled addTarget:self action:@selector(filedChangeValue:) forControlEvents:UIControlEventEditingChanged];
            _numberFiled = numberFiled;
        } else if (indexPath.row == 3) {
            if (_sendPartTimeModel.partTime) {
                cell.lastLabel.text = @"已选择";
            }else if (!_sendPartTimeModel.partTime){
                cell.lastLabel.text = nil;
            }
        } else if (indexPath.row == 4) {
            cell.lastLabel.text = self.JobWages;
        } else if (indexPath.row == 5) {
            cell.lastLabel.text = self.JJobMoney;
        } else if (indexPath.row == 6) {
            cell.lastLabel.text = self.JobDate;
        } else if (indexPath.row == 7) {
            cell.lastLabel.text = self.JobEndDate;
        } else if (indexPath.row == 8) {
            cell.lastLabel.text = self.JobWrite;
        } else if (indexPath.row == 9) {
            cell.lastLabel.text = self.JobAddress;
        } else if (indexPath.row == 10) {
            cell.lastLabel.text = self.JobPlace;
        } else if (indexPath.row == 11) {
            cell.lastLabel.text = self.JJobPeopleName;
        } else if (indexPath.row == 12) {
            cell.lastLabel.text = self.JobPhone;
        } else if (indexPath.row == 13) {
            cell.lastLabel.text = self.EmailVC;
        }
    }
    
    
    
    
    cell.lastLabel.textColor = Color(138, 138, 138);
    cell.lastLabel.textAlignment = NSTextAlignmentRight;
    cell.jtimage.image = [UIImage imageNamed:@"find_go"];
    cell.nameLabel.textColor = Color(138, 138, 138);
    cell.nameLabel.text = [self.array objectAtIndex:indexPath.row];
    
    
    return cell;
}

-(BOOL)filedChangeValue:(UITextField *)textFile{
    MYLog(@"%@",textFile.text);
    if ([self isPureNumandCharacters:textFile.text]) {
        [appDelegate.appDefault setObject:textFile.text forKey:@"number"];
        [appDelegate.appDefault synchronize];
        
    } else {
        [self pushAlertViewWithTitle:@"请输入整数"];
        textFile.text = nil;
    }
    return YES;
}

// 判断字符串是否为纯数字
- (BOOL)isPureNumandCharacters:(NSString *)string
{
    string = [string stringByTrimmingCharactersInSet:
              [NSCharacterSet decimalDigitCharacterSet]];
    if(string.length > 0)
    {
        return NO;
    }
    return YES;
}


#pragma mark - 发布兼职
- (void)actionButton:(UIButton *)button
{
    _sendPartTimeModel.personCount = [_numberFiled.text intValue];
    if (_sendPartTimeModel.jobName && _sendPartTimeModel.jobMainType && _sendPartTimeModel.personCount && _sendPartTimeModel.partTime && _sendPartTimeModel.salary && _sendPartTimeModel.salaryPay && _sendPartTimeModel.partTimeBegin && _sendPartTimeModel.partTimeEnd && _sendPartTimeModel.jobDesc && _sendPartTimeModel.jobArea && _sendPartTimeModel.jobAddress && _sendPartTimeModel.linkman && _sendPartTimeModel.linkmanPhone && _sendPartTimeModel.receiveEmail) {
        
        NSString *url = [baseUrl stringByAppendingString:@"insertPhonePartTimeJob.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        _sendPartTimeModel.companyId = parameters[@"companyId"];
        _sendPartTimeModel.releaseStatus = @"01";
        MYLog(@"%@",_sendPartTimeModel.mj_keyValues);
        [zyzpHttpTool POST:url parameters:_sendPartTimeModel.mj_keyValues progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@",responseObject);
            if ([responseObject[@"status"] isEqualToString:@"01"]) {
                [self pushAlertViewWithTitle:@"发布兼职成功!"];
                [self.navigationController popViewControllerAnimated:YES];
            }else if ([responseObject[@"status"] isEqualToString:@"02"]){
                [self pushAlertViewWithTitle:@"发布兼职失败!"];
            }else if ([responseObject[@"status"] isEqualToString:@"500"]){
                [self pushAlertViewWithTitle:@"请输入正确的兼职信息"];
            }
        } failure:^(NSError *error) {
            MYLog(@"%@",error);
        }];
    } else {
        [self pushAlertViewWithTitle:@"请填写完整的兼职内容"];
    }
    
    
}
#pragma mark - 保存为未发布
- (void)actionButtonone:(UIButton *)btn
{
    _sendPartTimeModel.personCount = [_numberFiled.text intValue];
    if (_sendPartTimeModel.jobName && _sendPartTimeModel.jobMainType && _sendPartTimeModel.personCount && _sendPartTimeModel.partTime && _sendPartTimeModel.salary && _sendPartTimeModel.salaryPay && _sendPartTimeModel.partTimeBegin && _sendPartTimeModel.partTimeEnd && _sendPartTimeModel.jobDesc && _sendPartTimeModel.jobArea && _sendPartTimeModel.jobAddress && _sendPartTimeModel.linkman && _sendPartTimeModel.linkmanPhone && _sendPartTimeModel.receiveEmail) {
        
        NSString *url = [baseUrl stringByAppendingString:@"insertPhonePartTimeJob.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        _sendPartTimeModel.companyId = parameters[@"companyId"];
        _sendPartTimeModel.releaseStatus = @"02";
        MYLog(@"%@",_sendPartTimeModel.mj_keyValues);
        [zyzpHttpTool POST:url parameters:_sendPartTimeModel.mj_keyValues progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@",responseObject);
            if ([responseObject[@"status"] isEqualToString:@"01"]) {
                [self pushAlertViewWithTitle:@"保存未发布成功!"];
                [self.navigationController popViewControllerAnimated:YES];
            }else if ([responseObject[@"status"] isEqualToString:@"02"]){
                [self pushAlertViewWithTitle:@"保存未发布失败!"];
            }else if ([responseObject[@"status"] isEqualToString:@"500"]){
                [self pushAlertViewWithTitle:@"请输入正确的兼职信息"];
            }
        } failure:^(NSError *error) {
            MYLog(@"%@",error);
        }];
    } else {
        [self pushAlertViewWithTitle:@"请填写完整的兼职内容"];
    }
}


-(void)pushAlertViewWithTitle:(NSString *)title{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:title delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    [NSTimer scheduledTimerWithTimeInterval:2.30f
                                     target:self
                                   selector:@selector(applyPositiTimerFireMethod:)
                                   userInfo:alert
                                    repeats:YES];
    [alert show];
}
- (void)applyPositiTimerFireMethod:(NSTimer*)theTimer//弹出框
{
    UIAlertView *alert = (UIAlertView*)[theTimer userInfo];
    [alert dismissWithClickedButtonIndex:0 animated:NO];
    alert =NULL;
}


// cell的点击方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        ZWNameVC *newJobName = [[ZWNameVC alloc] init];
        newJobName.name = _sendPartTimeModel.jobName;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:newJobName animated:YES];
    } else if (indexPath.row == 1) {
        newJobNameViewController *newJobClass = [[newJobNameViewController alloc] init];
        [self.navigationController pushViewController:newJobClass animated:YES];
    } else if (indexPath.row == 2) {
//        newJobNumberViewController *newJobNumber = [[newJobNumberViewController alloc] init];
        [_numberFiled becomeFirstResponder];
//        [self.navigationController pushViewController:newJobNumber animated:YES];
    } else if (indexPath.row == 3) {
        partTimeDateController *ptVC = [partTimeDateController new];
        ptVC.partTime = _model.partTime;
       [self.navigationController pushViewController:ptVC animated:YES];
        
    } else if (indexPath.row == 4) {
        JZMoneyVC *newJobWages = [[JZMoneyVC alloc] init];
        newJobWages.wags = _sendPartTimeModel.salary;
        [self.navigationController pushViewController:newJobWages animated:YES];
    } else if (indexPath.row == 5) {
        JJobMoneyVC *jJobManey = [[JJobMoneyVC alloc] init];
        [self.navigationController pushViewController:jJobManey animated:YES];
    } else if (indexPath.row == 6) {
        newJobDateViewController *jobDataVC = [[newJobDateViewController alloc] init];
        [self.navigationController pushViewController:jobDataVC animated:YES];
    } else if (indexPath.row == 7) {
        JJobEndDateVC *jobEndDataVC = [[JJobEndDateVC alloc] init];
        [self.navigationController pushViewController:jobEndDataVC animated:YES];
    } else if (indexPath.row == 8) {
        newJobWriteViewController *newJobWrite = [[newJobWriteViewController alloc] init];
        newJobWrite.describe = _sendPartTimeModel.jobDesc;
        [self.navigationController pushViewController:newJobWrite animated:YES];
    } else if (indexPath.row == 9) {
        newJobAddressViewController *newJobAddress = [[newJobAddressViewController alloc] init];
        [self.navigationController pushViewController:newJobAddress animated:YES];
    } else if (indexPath.row == 10) {
        ZWJobAddressVC *newJobPlace = [[ZWJobAddressVC alloc] init];
        newJobPlace.addre = _sendPartTimeModel.jobAddress;
        [self.navigationController pushViewController:newJobPlace animated:YES];
    } else if (indexPath.row == 11) {
        JJobPeopleNameVC *peopleName = [[JJobPeopleNameVC alloc] init];
        peopleName.name = _sendPartTimeModel.linkman;
        [self.navigationController pushViewController:peopleName animated:YES];
    } else if (indexPath.row == 12) {
        newJobPhoneViewController *newJobPhone = [[newJobPhoneViewController alloc] init];
        newJobPhone.numb = _sendPartTimeModel.linkmanPhone;
        [self.navigationController pushViewController:newJobPhone animated:YES];
    } else if (indexPath.row == 13) {
        WZSEmailViewController *emailVC = [[WZSEmailViewController alloc] init];
        emailVC.email = _sendPartTimeModel.receiveEmail;
        [self.navigationController pushViewController:emailVC animated:YES];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

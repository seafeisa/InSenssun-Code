//
//  discoverViewController.m
//  RecruitmentProduct
//
//  Created by runsheng on 16/3/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  找工作--发现

#import "discoverViewController.h"
#import "Common.h"
#import "discoverTableViewCell.h"
#import "secondViewController.h"
#import "publishViewController.h"
#import "adviceViewController.h"
#import "interviewViewController.h"
#import "schoolViewController.h"
#import "companyViewController.h"
#import "findEnterpController.h"
#import "Account.h"
#import "publishViewController.h"
#import "QYJobViewController.h"
#import "QYmanageTableViewCell.h"
#import "QYpositionManageViewController.h"
#import "QYJianZhiViewController.h"
#import "AppDelegate.h"
#import "zyjyTabbarController.h"
#import "zyzpHttpTool.h"
#import "NSString+locationJson.h"



@interface discoverViewController ()

@property (nonatomic, strong) NSArray *titleArray;
@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) NSArray *imageArray;

@property (nonatomic, strong) NSString *city;

@property (nonatomic, strong) NSString *cityName;

@property (nonatomic, strong) NSString *conLogo;

@end

@implementation discoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // self.view.backgroundColor = RandomColor;
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    // 4.15 新增 title
    [self getdata];
    
    // 4.15 改动  从cell初始化里面移动到这
    
}

- (void)getdata
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionSelect:) name:@"seleciCityForFound" object:nil];
}

- (void)actionSelect:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    _city = dic[@"selectCityKey"];
    _cityName = dic[@"selectCityName"];
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.hidesBottomBarWhenPushed = NO;
    // 清除所选择的兼职时间记录
    [appDelegate.appDefault removeObjectForKey:@"indexPathArrs"];
    
    [appDelegate.appDefault removeObjectForKey:@"number"];
    self.tabBarController.tabBar.hidden = NO;
    if ([[Account currentAccount] isLogin]) {
        if ([[Account currentAccount] isCompany]) {
            [self getConData];
            self.title = @"职位";
            self.dataArray = @[@"发布新职位", @"发布兼职", @"管理职位列表", @"管理兼职列表"];
        }else{
            self.title = @"发现";
            self.titleArray = @[@"招聘会", @"求职指导", @"模拟面试", @"行业名企", @"校园招聘", @"指缘交友"];
            self.imageArray = @[@"find_meeting", @"find_zd", @"find_mnms", @"find_hymq", @"find_xyzp", @"切换"];
        }
    }else{
        self.title = @"发现";
        self.titleArray = @[@"招聘会", @"求职指导", @"模拟面试", @"行业名企", @"校园招聘", @"指缘交友"];
        self.imageArray = @[@"find_meeting", @"find_zd", @"find_mnms", @"find_hymq", @"find_xyzp", @"切换"];
    }
    [self.tableView reloadData];
}

- (void)getConData
{
    NSString *url = [baseUrl stringByAppendingString:@"selectCompanyInfo.htm"];
    NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
    [zyzpHttpTool GET:url parameters:parameters progress:^{
        
    } success:^(id responseObject) {
        MYLog(@"%@", responseObject);
        NSDictionary *dic = responseObject[@"data"];
        _conLogo = dic[@"logoFilePath"];
    } failure:^(NSError *error) {
        
    }];
}




#pragma mark - Table view data source

// 设置每个分区cell个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if ([[Account currentAccount] isLogin]) {
        if ([[Account currentAccount] isCompany]) {
            return self.dataArray.count;
        }else{
            return self.titleArray.count;
        }
    }else{
        return self.titleArray.count;
    }
}

// 设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 4.15改动 60改成43
    return 43;
}

// cell赋值
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([[Account currentAccount] isLogin]) {
        if ([[Account currentAccount] isCompany]) {
            static NSString *identifier = @"QYmanageVC";
            QYmanageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            if (cell == nil) {
                cell = [[QYmanageTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
            }
            // 后面有小箭头方法~~
            //    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.nameLabel.textColor = Color(138, 138, 138);
            cell.nameLabel.text = self.dataArray[indexPath.row];
            cell.jtimage.image = [UIImage imageNamed:@"find_go"];
            
            return cell;
        }
    }
    static NSString *identifier = @"identifier";
    discoverTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[discoverTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
        // 4.15改动  小箭头方法删除
        cell.titleLabel.text = [self.titleArray objectAtIndex:indexPath.row];
        
    }
    
    cell.titleIamgeView.image = [UIImage imageNamed:self.imageArray[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[Account currentAccount] isLogin]) {
        if ([[Account currentAccount] isCompany]) {
            if (indexPath.row == 0) {
                QYJobViewController *QYjob = [[QYJobViewController alloc] init];
                [self.navigationController pushViewController:QYjob animated:YES];
            } else if (indexPath.row == 1) {
                publishViewController *publish = [[publishViewController alloc] init];
                [self.navigationController pushViewController:publish animated:YES];
            } else if (indexPath.row == 2) {
                QYpositionManageViewController *position = [[QYpositionManageViewController alloc] init];
                position.conLogo = _conLogo;
                [self.navigationController pushViewController:position animated:YES];
            }else if (indexPath.row == 3) {
                QYJianZhiViewController *jianzhi = [[QYJianZhiViewController alloc] init];
                jianzhi.conLogo = _conLogo;
                [self.navigationController pushViewController:jianzhi animated:YES];
            }
        }else{
            if (indexPath.row == 0) {
                secondViewController *secondVC = [[secondViewController alloc] init];
                [self.navigationController pushViewController:secondVC animated:YES];
            } else if (indexPath.row == 1) {
                adviceViewController *adviceVC = [[adviceViewController alloc] init];
                [self.navigationController pushViewController:adviceVC animated:YES];
                
            } else if (indexPath.row == 2) {
                
                interviewViewController *interviewVC = [[interviewViewController alloc] init];
                [self.navigationController pushViewController:interviewVC animated:YES];
            } else if (indexPath.row == 3) {
                // 4.20改动找名企页面
                findEnterpController *company = [[findEnterpController alloc] init];
                company.locationKey = [NSString argumentParsing:[appDelegate.appDefault objectForKey:@"toOtherStrLocation"] positive:NO];
                MYLog(@"%@", company.locationKey);
                self.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:company animated:YES];
            } else if (indexPath.row == 4) {
                schoolViewController *school = [[schoolViewController alloc] init];
                [self.navigationController pushViewController:school animated:YES];
            } else if (indexPath.row == 5) {
                [self presentViewController:[[zyjyTabbarController alloc] initWithWindow:self.view.window] animated:YES completion:nil];
            }
        }
    }else{
        if (indexPath.row == 0) {
            secondViewController *secondVC = [[secondViewController alloc] init];
            [self.navigationController pushViewController:secondVC animated:YES];
        } else if (indexPath.row == 1) {
            adviceViewController *adviceVC = [[adviceViewController alloc] init];
            [self.navigationController pushViewController:adviceVC animated:YES];
            
        } else if (indexPath.row == 2) {
            
            interviewViewController *interviewVC = [[interviewViewController alloc] init];
            [self.navigationController pushViewController:interviewVC animated:YES];
        } else if (indexPath.row == 3) {
            // 4.20改动找名企页面
            findEnterpController *company = [[findEnterpController alloc] init];
            company.locationKey = [NSString argumentParsing:[appDelegate.appDefault objectForKey:@"toOtherStrLocation"] positive:NO];
            [self.navigationController pushViewController:company animated:YES];
        } else if (indexPath.row == 4) {
            schoolViewController *school = [[schoolViewController alloc] init];
            [self.navigationController pushViewController:school animated:YES];
        } else if (indexPath.row == 5) {
            [self presentViewController:[[zyjyTabbarController alloc] initWithWindow:self.view.window] animated:YES completion:nil];        }
    }
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

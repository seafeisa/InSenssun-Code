//
//  QYpositionManageViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/19.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QYpositionManageViewController : UIViewController

// 公司logo
@property (nonatomic, strong) NSString *conLogo;

@end

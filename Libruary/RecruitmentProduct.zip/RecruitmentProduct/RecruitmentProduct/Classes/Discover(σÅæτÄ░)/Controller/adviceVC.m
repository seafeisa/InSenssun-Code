//
//  adviceVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/5.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  求职指导详情页面

#import "adviceVC.h"
#import "Common.h"

@interface adviceVC ()

@end

@implementation adviceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    //self.tabBarController.tabBar.hidden = YES;
//    [self addbarButton];
    self.title = @"文章详情";
    self.navigationController.navigationBar.translucent = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    [self addWebView];
}

// 右边分享按钮
- (void)addbarButton
{
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:(UIBarButtonSystemItemAction) target:self action:@selector(rightButton:)];
    self.navigationItem.rightBarButtonItem = rightBarButton;
}

- (void)addWebView
{
    NSString *aaa = self.adviceId;
    NSString *str = [baseUrl stringByAppendingString:@"selectCareerAdviceByCareerAdviceId.htm"];
    NSString *string = [str stringByAppendingString:@"?careerAdviceId="];
    NSString *url = [string stringByAppendingString:aaa];
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    webView.backgroundColor = [UIColor whiteColor];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];

    [self.view addSubview:webView];
    [webView loadRequest:request];
}

- (void)rightButton:(UIButton *)button
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"此处是分享" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alertView show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

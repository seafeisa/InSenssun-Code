//
//  interviewViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/3/31.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  模拟面试


#import "interviewViewController.h"
#import "interviewTableViewCell.h"
#import "interviewVC.h"
#import "zyzpHttpTool.h"
#import "Common.h"
#import "Account.h"
#import "LoginViewController.h"
#import "zyzpNavigationController.h"
#import "GRscoreVC.h"

@interface interviewViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, assign) NSInteger num;

@property (nonatomic, strong) NSArray *nameArray;

@property (nonatomic, strong) NSArray *typeArray;

@end

@implementation interviewViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // 4.15 新增 title
    self.title = @"模拟面试";
    self.tableView.rowHeight = 86;
    self.typeArray = [NSArray array];
    [self getDataForUrl];
    [self addSubView];
}

- (void)getDataForUrl
{
    NSString *url = [baseUrl stringByAppendingString:@"selectPersonForPhone.htm"];
    NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
    MYLog(@"%@", parameters[@"personId"]);
    [zyzpHttpTool GET:url parameters:parameters progress:^{
        
    } success:^(id responseObject) {

        NSString *str = responseObject[@"systemPaperType"];
        self.typeArray = [str componentsSeparatedByString:@","];
    } failure:^(NSError *error) {
        MYLog(@"%@", error);
    }];
    
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.bounces = NO;
//    self.tableView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 86;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    NSArray *picArray = @[@"毕业生", @"市场", @"技术", @"文职"];
    interviewTableViewCell *cell = [interviewTableViewCell cellWithTableView:tableView];
    self.nameArray = @[@"毕业生篇", @"市场篇", @"技术篇", @"文职篇"];
    cell.titleLabel.text = _nameArray[indexPath.row];
    
    cell.titleimage.image = [UIImage imageNamed:picArray[indexPath.row]];
    

    return cell;
}

// cell的点击方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([[Account currentAccount] isLogin]) {
        
        
        NSString *str = [baseUrl stringByAppendingString:@"toSystemInterviewByType.htm"];
        NSMutableDictionary *parameters = [[Account currentAccount] requestParams];
        parameters[@"paperType"] = [@"0"stringByAppendingString:[NSString stringWithFormat:@"%ld", indexPath.row + 1]];
        [zyzpHttpTool GET:str parameters:parameters progress:^{
            
        } success:^(id responseObject) {
            MYLog(@"%@", responseObject);
            NSString *type = [@"0"stringByAppendingString:[NSString stringWithFormat:@"%ld", indexPath.row + 1]];
            for (NSString *strr in self.typeArray) {
                
                if ([strr isEqualToString:type]) {
                    
                    
                    GRscoreVC *scoreVC = [[GRscoreVC alloc] init];
                    scoreVC.titleName = _nameArray[indexPath.row];
                    scoreVC.responseObject = responseObject;
                    [self.navigationController pushViewController:scoreVC animated:YES];
                    return;
                }
            }
        
                interviewVC *interview = [[interviewVC alloc] init];
                interview.name = _nameArray[indexPath.row];
                interview.responseObject = responseObject;
                interview.per = responseObject[0][@"paperType"];

                [self.navigationController pushViewController:interview animated:YES];
                
            
            
        } failure:^(NSError *error) {
            
        }];
    } else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请登录后参与!!!" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去登录", nil];
        
        [alertView show];
    }
}

/**
 *  alert点击方法
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        zyzpNavigationController *zyzp = [[zyzpNavigationController alloc] initWithRootViewController:loginVC];
        
        [self presentModalViewController:zyzp animated:YES];
        //        [self.navigationController dismissModalViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

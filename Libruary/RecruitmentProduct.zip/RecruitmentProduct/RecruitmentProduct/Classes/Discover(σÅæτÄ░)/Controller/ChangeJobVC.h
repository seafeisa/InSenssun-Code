//
//  ChangeJobVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/27.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QYposition.h"

@interface ChangeJobVC : UIViewController

@property (nonatomic, strong) NSString *JobNature;

@property (nonatomic, strong) QYposition *model;

@end

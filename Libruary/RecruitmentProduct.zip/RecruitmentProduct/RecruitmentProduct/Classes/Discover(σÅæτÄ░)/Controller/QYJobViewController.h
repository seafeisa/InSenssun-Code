//
//  QYJobViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/15.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QYchangeJob.h"

@interface QYJobViewController : UIViewController

/**
 *  4.25新增  职位性质
 */
@property (nonatomic, strong) NSString *JobNature;

@property (nonatomic, strong) QYchangeJob *model;


@property (nonatomic, strong) NSString *ididididid;

@property (nonatomic, strong) NSString *shuang;

@end

//
//  WZSEmailViewController.h
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/23.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZSEmailViewController : UIViewController

@property (nonatomic, strong) NSString *email;

@end

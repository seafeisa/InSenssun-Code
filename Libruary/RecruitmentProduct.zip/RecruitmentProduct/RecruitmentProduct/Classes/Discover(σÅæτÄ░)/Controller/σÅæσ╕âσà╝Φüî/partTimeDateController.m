//
//  partTimeDateController.m
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/11.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "partTimeDateController.h"
#import "UIView+ZYFrame.h"
#import "Common.h"
#import "zyCollectionViewCell.h"
#import "partTimeCollertionCell.h"
#import "zyNavigationItemTool.h"
#import "AppDelegate.h"

@interface partTimeDateController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, strong) NSArray *myTimeArr;

@property (nonatomic, strong) NSArray *weekTitleArr;
@property (nonatomic, strong) NSArray *dateArr;

@property (nonatomic, strong) NSMutableArray *keyArrs;

@property (nonatomic, strong) NSMutableArray *indexPathArr;

@property (nonatomic, copy) NSString *strs;
@end

@implementation partTimeDateController

static NSString * const reuseIdentifier = @"Cell";



- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"兼职时间";
    self.navigationController.navigationBar.translucent = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    [self addRightButton];
    self.weekTitleArr = @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"];
    self.dateArr = @[@"001",@"002",@"003",@"004",@"005",@"006",@"007",@"011",@"022",@"033",@"044",@"055",@"066",@"077",@"111",@"222",@"333",@"444",@"555",@"666",@"777"];
    [self didSetUpCollectionView];
//    self.navigationController.navigationBar.translucent = NO;
    //[self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    // Do any additional setup after loading the view.
}
-(NSArray *)myTimeArr{
    if (!_myTimeArr) {
        _myTimeArr = [_partTime componentsSeparatedByString:@","];
    }
    return _myTimeArr;
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(partTimeRightButtonClick)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    [zyNavigationItemTool setUpLeftBtnWithTarget:self action:@selector(actionLeftButton) iamge:[UIImage imageNamed:@"nav_back"] Title:nil];
}
/**
 *   点击返回navigationBar
 */
-(void)actionLeftButton{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"partTimeDateNotifi" object:nil];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)partTimeRightButtonClick{
     [[NSNotificationCenter defaultCenter] postNotificationName:@"partTimeDateNotifi" object:_strs];
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSMutableArray *)indexPathArr{
    if (!_indexPathArr) {
        _indexPathArr = [NSMutableArray array];
    }
    return _indexPathArr;
}
-(NSMutableArray *)keyArrs{
    if (!_keyArrs) {
        _keyArrs = [NSMutableArray array];
        
    }
    return _keyArrs;
}

- (void)didSetUpCollectionView{
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    float margin = 10;
    float W = (screenW - 2 *margin )/9;
    
    flowLayout.itemSize = CGSizeMake(W,W);
    if (screenW == 414) {
       flowLayout.minimumLineSpacing = 8;
        flowLayout.minimumInteritemSpacing = 8;
    }else{
        // 每列最小间距
        flowLayout.minimumLineSpacing = 5;
        // 每行最小间距
        flowLayout.minimumInteritemSpacing = 3;
    }
    
    // 设置滚动方向
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    // 设置header区域大小
  //  flowLayout.headerReferenceSize = CGSizeMake(screenW, 50);
    
    flowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(20, 50, screenW - 20, 500) collectionViewLayout:flowLayout];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:collectionView];
    
    /**
     *  上中晚 硬加上去的
     */
    UIView *view =[[UIView alloc] init];
    //view.backgroundColor = [UIColor redColor];
    
    
   
    if (screenW == 375) {
        view.y = 69.50 + 50 + 64 + 1;
        view.height = 124.5 + 6;
        view.x = 5;
        view.width = 20;
    }else if (screenW == 320){
        view.y = 63.5 + 50 + 64;
        view.height = 105.8 + 6;
        view.x = 5;
        view.width = 20;
    }else if (screenW == 414){
        view.y = 73.6 + 50 + 64;
        view.height = 147.5;
        view.x = 5;
        view.width = 20;
    }
    NSArray *labTitleArr = @[@"上",@"下",@"晚"];
    for (int i = 0; i < 3; i++) {
        UILabel *lab = [[UILabel alloc] init];
        lab.x = 0;
        lab.width = view.width;
        lab.height = (view.height - 2 *5)/3;
        lab.y = i * (lab.height + 5);
        lab.text = labTitleArr[i];
        lab.textColor = [UIColor brownColor];
        [view addSubview:lab];
    }
    [self.view addSubview:view];
    
    UILabel *promptLab = [[UILabel alloc] init];
    promptLab.x = 0;
    promptLab.y = 400;
    promptLab.width = screenW;
    promptLab.height  = 40;
    promptLab.textColor = [UIColor brownColor];
    promptLab.text = @"点击方框选择所需兼职时间";
    promptLab.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:promptLab];
    
    
    [collectionView registerClass:[zyCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [collectionView registerClass:[partTimeCollertionCell class] forCellWithReuseIdentifier:@"numberCell"];
    _collectionView = collectionView;
//    [collectionView registerClass:[tradeHeaderReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];
//    
}




#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 2;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    if (section == 0) {
        return self.weekTitleArr.count;
    }else{
      return 21;
    }
    
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    partTimeCollertionCell *littleCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"numberCell" forIndexPath:indexPath];
    
    // zyCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    NSArray *subViews = littleCell.subviews;
    for (UIView *vi in subViews) {
        [vi removeFromSuperview];
    }
    
    
    if (indexPath.section == 0) {
        
        [littleCell.button setTitle:self.weekTitleArr[indexPath.row] forState:UIControlStateNormal];
        [littleCell.button setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
        
    }else{
        littleCell.title = self.dateArr[indexPath.row];
        littleCell.isShow  = NO;
        
        NSArray *arr = [appDelegate.appDefault objectForKey:@"indexPathArrs"];
        
        for (NSString *index in arr) {
            
            
            NSString *str = [NSString stringWithFormat:@"%ld",indexPath.row];
            if ([str isEqualToString:index]) {
                
                UIImageView *imv = [[UIImageView alloc] init];
                imv.image = [UIImage imageNamed:@"selectRed"];
                imv.width = littleCell.width/2;
                imv.height = littleCell.height/2;
                imv.x = littleCell.width/4;
                imv.y = littleCell.height/4;
                [littleCell addSubview:imv];
            }
        }
        
//        for (NSString *str in self.myTimeArr) {
//            if ([str isEqualToString:littleCell.title]) {
//                littleCell.title = self.dateArr[indexPath.row];
//                UIImageView *imv = [[UIImageView alloc] init];
//                imv.image = [UIImage imageNamed:@"partTimeSelected"];
//                imv.x = 0;
//                imv.y = 0;
//                imv.width = littleCell.width-10;
//                imv.height = littleCell.height-10;
//                [littleCell addSubview:imv];
//            }
//            
//            
//        }
//     
        
    }
    
    
    return littleCell;
}
#pragma mark <UICollectionViewDelegate>

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    partTimeCollertionCell *mycell = (partTimeCollertionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    
    
    UIImageView *imv = [[UIImageView alloc] init];
    imv.image = [UIImage imageNamed:@"selectRed"];
    
    imv.width = mycell.width/2;
    imv.height = mycell.height/2;
    imv.x = mycell.width/4;
    imv.y = mycell.height/4;
    
    if (mycell.isShow) {
        mycell.isShow = NO;
        [self.keyArrs removeObject:mycell.title];
        mycell.title = self.dateArr[indexPath.row];
        [self.indexPathArr removeObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
        [imv removeFromSuperview];
        
        
        
    }else{
        mycell.isShow = YES;
        [self.keyArrs addObject:mycell.title];
        mycell.title = self.dateArr[indexPath.row];
        [self.indexPathArr addObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
        [mycell addSubview:imv];
    }

//    MYLog(@">>>>>>>>>>maxY>>%f",CGRectGetMaxY(mycell.frame)) ;
//    MYLog(@">>>>>>>>y===%f",mycell.y);
    MYLog(@"%@",self.indexPathArr);
    [appDelegate.appDefault setObject:self.indexPathArr forKey:@"indexPathArrs"];
    [appDelegate.appDefault synchronize];
    _strs = [self.keyArrs componentsJoinedByString:@","];
  
}



@end

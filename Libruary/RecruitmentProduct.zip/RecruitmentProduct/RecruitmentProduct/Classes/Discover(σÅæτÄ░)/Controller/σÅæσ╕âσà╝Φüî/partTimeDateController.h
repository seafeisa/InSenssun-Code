//
//  partTimeDateController.h
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/11.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface partTimeDateController : UIViewController
@property (nonatomic, strong)  UICollectionView *collectionView;

@property (nonatomic, copy) NSString *partTime ;
@end

//
//  WZSEmailViewController.m
//  RecruitmentProduct
//
//  Created by runsheng on 16/5/23.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "WZSEmailViewController.h"
#import "Common.h"
#import "NSString+Mobile.h"

@interface WZSEmailViewController ()

@property (nonatomic, strong) UITextField *textF;

@end

@implementation WZSEmailViewController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"简历接收邮箱";
    self.view.backgroundColor = Color(200, 200, 200);
    self.navigationController.navigationBar.translucent = NO;
    self.textF = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, screenW, 43)];
    _textF.font = [UIFont systemFontOfSize:15.0];
    _textF.backgroundColor = [UIColor whiteColor];
    _textF.placeholder = @"请输入简历接收邮箱";
    _textF.text = self.email;
    _textF.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_textF];
    [self addRightButton];
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionButton:)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
}

- (void)actionButton:(UIBarButtonItem *)button
{
    
    if ([NSString isValidateEmail:self.textF.text]) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        dic[@"Email"] = self.textF.text;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"EmailVC" object:dic];
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        
        UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请输入正确的邮箱格式" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alter show];
        
        
    }
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

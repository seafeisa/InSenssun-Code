//
//  LoadDataPartTimeVC.h
//  RecruitmentProduct
//
//  Created by zy on 16/5/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "homePartTimeDateController.h"

@interface LoadDataPartTimeVC : homePartTimeDateController

@end

//
//  LoadDataPartTimeVC.m
//  RecruitmentProduct
//
//  Created by zy on 16/5/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "LoadDataPartTimeVC.h"
#import "Common.h"
#import "UIView+ZYFrame.h"
#import "partTimeCollertionCell.h"

@interface LoadDataPartTimeVC ()

@end

@implementation LoadDataPartTimeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    partTimeCollertionCell *mycell = (partTimeCollertionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    
    
    UIImageView *imv = [[UIImageView alloc] init];
    imv.image = [UIImage imageNamed:@"partTimeSelected"];
    imv.x = 0;
    imv.y = 0;
    imv.width = mycell.width-10;
    imv.height = mycell.height-10;
    [mycell addSubview:imv];
    
    if (mycell.isShow) {
        mycell.isShow = NO;
        [self.keyArrs removeObject:mycell.title];
        mycell.title = self.dateArr[indexPath.row];
        [self.indexPathArr removeObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
        [imv removeFromSuperview];
        
        
        
    }else{ 
        mycell.isShow = YES;
        [self.keyArrs addObject:mycell.title];
        mycell.title = self.dateArr[indexPath.row];
        [self.indexPathArr addObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
        [mycell addSubview:imv];
    }
    
    //    MYLog(@">>>>>>>>>>maxY>>%f",CGRectGetMaxY(mycell.frame)) ;
    //    MYLog(@">>>>>>>>y===%f",mycell.y);
    //    MYLog(@"%@",self.indexPathArr);
    //    [appDelegate.appDefault setObject:self.indexPathArr forKey:@"indexPathArrs"];
    //    [appDelegate.appDefault synchronize];
    //    _strs = [self.keyArrs componentsJoinedByString:@","];
    // MYLog(@"%@",_strs);
}

@end

//
//  JZMoneyVC.m
//  RecruitmentProduct
//
//  Created by zy on 16/5/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JZMoneyVC.h"
#import "Common.h"
#import "UIView+ZYFrame.h"

@interface JZMoneyVC ()

@property (nonatomic, strong) UITextField *textF;

@end

@implementation JZMoneyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    self.title = @"兼职薪资";
    self.view.backgroundColor = Color(238, 238, 238);
    _textF = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, screenW, 40)];
    _textF.backgroundColor = [UIColor whiteColor];
    _textF.text = self.wags;
    _textF.placeholder = @"请输入薪资水平";
    [self.view addSubview:_textF];
    
    [self addRightButton];
    
}


// 判断字符串是否为纯数字
- (BOOL)isPureNumandCharacters:(NSString *)string
{
    string = [string stringByTrimmingCharactersInSet:
              [NSCharacterSet decimalDigitCharacterSet]];
    if(string.length > 0)
    {
        return NO;
    }
    return YES;
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionjzmoneyButton:)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
}

- (void)actionjzmoneyButton:(UIButton *)btn
{
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"jzmoney"] = _textF.text;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JZMONEY" object:dic];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

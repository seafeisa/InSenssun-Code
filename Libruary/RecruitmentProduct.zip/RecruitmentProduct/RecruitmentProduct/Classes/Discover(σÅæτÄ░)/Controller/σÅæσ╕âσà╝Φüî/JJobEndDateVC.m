//
//  JJobEndDateVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/5/2.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JJobEndDateVC.h"
#import "MHDatePicker.h"

@interface JJobEndDateVC ()

@end

@implementation JJobEndDateVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"结束日期";
    self.view.backgroundColor = [UIColor whiteColor];
    MHDatePicker *datePicker = [[MHDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    
    __weak typeof(self) weakSelf = self;
    [datePicker didFinishSelectedDate:^(NSDate *selectedDate) {
        
        NSString *birthday = [weakSelf dateStringWithDate:selectedDate DateFormat:@"yyyy-M-dd"];
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        dic[@"Date"] = birthday;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"JobEndDate" object:dic];
        
        [self.navigationController popViewControllerAnimated:YES];
        
        NSLog(@"%@", birthday);
    }];
}

- (NSString *)dateStringWithDate:(NSDate *)date DateFormat:(NSString *)dateFormat
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"]];
    NSString *str = [dateFormatter stringFromDate:date];
    return str ? str : @"";
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

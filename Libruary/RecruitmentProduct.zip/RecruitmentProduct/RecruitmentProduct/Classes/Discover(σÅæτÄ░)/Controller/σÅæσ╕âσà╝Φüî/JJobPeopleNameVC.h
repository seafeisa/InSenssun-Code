//
//  JJobPeopleNameVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/29.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JJobPeopleNameVC : UIViewController

@property (nonatomic, strong) NSString *name;

@end

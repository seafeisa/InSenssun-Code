//
//  JJobEndDateVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/5/2.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JJobEndDateVC : UIViewController

@end

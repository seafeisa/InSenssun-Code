//
//  JZMoneyVC.h
//  RecruitmentProduct
//
//  Created by zy on 16/5/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZMoneyVC : UIViewController

@property (nonatomic, strong) NSString *wags;

@end

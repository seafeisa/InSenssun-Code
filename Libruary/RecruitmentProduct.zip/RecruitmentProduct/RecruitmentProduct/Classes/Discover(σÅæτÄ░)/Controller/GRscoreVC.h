//
//  GRscoreVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/23.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GRscoreVC : UIViewController

@property (nonatomic, strong) NSString *typeId;
@property (nonatomic, strong) NSMutableArray *asArray;


@property (nonatomic, strong) NSString *titleName;

@property (nonatomic, strong) id responseObject;

@end

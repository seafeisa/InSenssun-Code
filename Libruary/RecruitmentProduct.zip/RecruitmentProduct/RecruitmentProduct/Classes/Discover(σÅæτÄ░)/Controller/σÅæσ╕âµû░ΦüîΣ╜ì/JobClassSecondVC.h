//
//  JobClassSecondVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobClassSecondVC : UIViewController

@property (nonatomic, strong) NSArray *cIndustryArray;

@property (nonatomic, strong) NSString *dicKey;

@property (nonatomic, strong) NSString *titleName;

@end

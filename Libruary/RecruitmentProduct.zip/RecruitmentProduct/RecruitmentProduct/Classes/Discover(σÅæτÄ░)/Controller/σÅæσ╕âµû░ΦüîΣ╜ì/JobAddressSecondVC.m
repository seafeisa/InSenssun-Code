//
//  JobAddressSecondVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JobAddressSecondVC.h"
#import "JobAddressThirdVC.h"
#import "Common.h"

@interface JobAddressSecondVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *cityArray;

@property (nonatomic, strong) NSMutableArray *numArray;

@end

@implementation JobAddressSecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.titleName;
    [self addSubView];
    [self getData];
}

- (void)getData
{
    self.cityArray = [NSMutableArray array];
    self.numArray = [NSMutableArray array];
    for (NSDictionary *dic in self.clistArray) {
        
        if (dic[@"areaParentId"] == self.dickey) {
            NSString *str = dic[@"dicValue"];
            NSString *num = dic[@"dicKey"];
            [self.cityArray addObject:str];
            [self.numArray addObject:num];
        }
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.cityArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"addressSecondVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.cityArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    JobAddressThirdVC *addressThird = [[JobAddressThirdVC alloc] init];
    
    addressThird.firstDickey = self.dickey;
    addressThird.alistArray = self.alistArray;
    addressThird.dickey = self.numArray[indexPath.row];
    addressThird.titleName = self.cityArray[indexPath.row];
    addressThird.bigTitleName = self.titleName;
    
    [self.navigationController pushViewController:addressThird animated:YES];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

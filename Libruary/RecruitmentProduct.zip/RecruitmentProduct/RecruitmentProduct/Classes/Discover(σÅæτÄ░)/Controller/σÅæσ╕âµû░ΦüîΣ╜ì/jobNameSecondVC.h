//
//  jobNameSecondVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jobNameSecondVC : UIViewController

/**
 *  二级页面
 */

@property (nonatomic, strong) NSArray *twoArray;

@property (nonatomic, strong) NSString *dicKey;

@property (nonatomic, strong) NSString *titleName;

/**
*  三级页面
*/
@property (nonatomic, strong) NSArray *threeArray;


@end

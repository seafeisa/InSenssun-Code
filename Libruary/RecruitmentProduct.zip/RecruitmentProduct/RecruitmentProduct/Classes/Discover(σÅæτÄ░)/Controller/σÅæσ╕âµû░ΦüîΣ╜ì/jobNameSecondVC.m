//
//  jobNameSecondVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "jobNameSecondVC.h"
#import "Common.h"
#import "jobNameThirdVC.h"

@interface jobNameSecondVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *numberArray;

@end

@implementation jobNameSecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.titleName;
    [self addSubView];
    [self getData];
}

- (void)getData
{
    self.nameArray = [NSMutableArray array];
    self.numberArray = [NSMutableArray array];
    for (NSDictionary *dic in self.twoArray) {
        if (dic[@"parentCode"] == self.dicKey) {
            NSString *name = dic[@"dicValue"];
            NSString *num = dic[@"dicKey"];
            [self.nameArray addObject:name];
            [self.numberArray addObject:num];
        }
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"jobNameSecondVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.nameArray[indexPath.row];
    cell.textLabel.textColor = Color(138, 138, 138);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    jobNameThirdVC *nameThird = [[jobNameThirdVC alloc] init];
    
    nameThird.threeArray = self.threeArray;
    nameThird.titleName = self.nameArray[indexPath.row];
    nameThird.dicKey = self.numberArray[indexPath.row];
    
    
    [self.navigationController pushViewController:nameThird animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

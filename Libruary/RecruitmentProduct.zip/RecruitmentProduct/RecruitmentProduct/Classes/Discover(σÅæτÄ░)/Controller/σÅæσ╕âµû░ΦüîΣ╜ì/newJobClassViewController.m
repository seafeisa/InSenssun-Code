//
//  newJobClassViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//  招聘会详细页面

/**
 *  4.18新增 职位类别
 */

#import "newJobClassViewController.h"
#import "Common.h"
#import "JobClassSecondVC.h"

@interface newJobClassViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

/**
 *  一级数组
 */
@property (nonatomic, strong) NSArray *pIndustry;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *numberArray;

/**
 *  二级数组
 */
@property (nonatomic, strong) NSArray *cIndustry;

@end

@implementation newJobClassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"职位类别";
    if (self.pushControllerType == 1) {
        self.title = @"行业类别";
    } else if ([self.shuang isEqualToString:@"666"]) {
        self.title = @"期望行业";
    }
    self.pIndustry = [NSArray array];
    self.cIndustry = [NSArray array];
    [self addSubView];
    if (self.isResume) {
        [self getDataForJsonResume];
    }else{
        [self getDataForJson];
    }
}
- (void)getDataForJsonResume{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"position1-2" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.pIndustry = dic[@"pPosition"];
    self.nameArray = [NSMutableArray array];
    self.numberArray = [NSMutableArray array];
    for (NSDictionary *dict in self.pIndustry) {
        NSString *name = dict[@"dicValue"];
        NSString *number = dict[@"dicKey"];
        [self.nameArray addObject:name];
        [self.numberArray addObject:number];
        
    }
    
    // 二级数组
    self.cIndustry = dic[@"cPosition"];
}


- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"industry" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.pIndustry = dic[@"pIndustry"];
    self.nameArray = [NSMutableArray array];
    self.numberArray = [NSMutableArray array];
    for (NSDictionary *dict in self.pIndustry) {
        NSString *name = dict[@"dicValue"];
        NSString *number = dict[@"dicKey"];
        [self.nameArray addObject:name];
        [self.numberArray addObject:number];

    }
    
    // 二级数组
    self.cIndustry = dic[@"cIndustry"];
    
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"JobClassVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.nameArray[indexPath.row];
    cell.textLabel.textColor = Color(138, 138, 138);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    JobClassSecondVC *jobClassSecond = [[JobClassSecondVC alloc] init];
    
    jobClassSecond.cIndustryArray = self.cIndustry;
    
    jobClassSecond.dicKey = self.numberArray[indexPath.row];
    
    jobClassSecond.titleName = self.nameArray[indexPath.row];
    
    [self.navigationController pushViewController:jobClassSecond animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

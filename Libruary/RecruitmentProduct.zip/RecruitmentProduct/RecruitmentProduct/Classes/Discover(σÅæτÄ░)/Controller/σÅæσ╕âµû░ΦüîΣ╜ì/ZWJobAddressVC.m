//
//  ZWJobAddressVC.m
//  RecruitmentProduct
//
//  Created by zy on 16/5/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "ZWJobAddressVC.h"
#import "Common.h"
#import "UIView+ZYFrame.h"

@interface ZWJobAddressVC ()

@property (nonatomic, strong) UITextField *textF;

@end

@implementation ZWJobAddressVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    self.title = @"工作地址";
    self.view.backgroundColor = Color(238, 238, 238);
    _textF = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, screenW, 40)];
    _textF.backgroundColor = [UIColor whiteColor];
    _textF.placeholder = @"请输入工作地址";
    _textF.text = self.addre;
    [self.view addSubview:_textF];
    
    [self addRightButton];
    
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionZWjobAddressButton:)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
}

- (void)actionZWjobAddressButton:(UIButton *)btn
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"zwjobaddress"] = _textF.text;
    
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ZWJOB" object:dic];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

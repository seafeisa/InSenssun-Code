//
//  JobAddressSecondVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobAddressSecondVC : UIViewController

/**
 *  二级数组
 */
@property (nonatomic, strong) NSArray *clistArray;

@property (nonatomic, strong) NSString *dickey;

@property (nonatomic, strong) NSString *titleName;

/**
 *  三级数组
 */
@property (nonatomic, strong) NSArray *alistArray;

@end

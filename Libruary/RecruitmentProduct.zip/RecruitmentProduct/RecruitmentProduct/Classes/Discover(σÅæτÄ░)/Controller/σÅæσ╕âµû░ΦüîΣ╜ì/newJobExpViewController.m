//
//  newJobExpViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 经验要求
 */

#import "newJobExpViewController.h"
#import "Common.h"

@interface newJobExpViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

/**
 *  经验要求
 */
@property (nonatomic, strong) NSMutableArray *JobExp;
@property (nonatomic, strong) NSMutableArray *expKeys;


@end

@implementation newJobExpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"经验要求";
    [self addSubView];
    [self getDataForJson];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"workhistory" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.JobExp = [NSMutableArray array];
    self.expKeys = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        NSString *str = dic[@"dicValue"];
        NSString *key = dic[@"dicKey"];
        [self.expKeys addObject:key];
        [self.JobExp addObject:str];
    }
}


- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
//    self.tableView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.JobExp.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobExcVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.JobExp[indexPath.row];

    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Exp"] = self.JobExp[indexPath.row];
    dic[@"expKey"] = self.expKeys[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobExp" object:dic];
    
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

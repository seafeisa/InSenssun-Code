//
//  JobAddressThirdVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobAddressThirdVC : UIViewController


@property (nonatomic, strong) NSArray *alistArray;

@property (nonatomic, strong) NSString *firstDickey;

@property (nonatomic, strong) NSString *dickey;

@property (nonatomic, strong) NSString *titleName;

@property (nonatomic, strong) NSString *bigTitleName;

@end

//
//  newJobAddressViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newJobAddressViewController : UIViewController
typedef enum{
    
    searchPositiTitle = 0,// 职位搜索的历史记录
    searchResumeTitle  // 人才搜索
}controllTitleType;

@property (nonatomic, assign) NSInteger pushControllerType;
@end

//
//  newJobPlaceViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 工作地址
 */

#import "newJobPlaceViewController.h"
#import "Common.h"
#import "JobPlaceSecondVC.h"

@interface newJobPlaceViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

/**
 *  一级数组
 */
@property (nonatomic, strong) NSArray *oneArray;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *numberArray;

/**
 *  二级数组
 */
@property (nonatomic, strong) NSArray *twoArray;

@end

@implementation newJobPlaceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"工作地址";
    if (self.pushControllerType == searchResumePlaceTitle) {
         self.title = @"期望工作地";
    }else if (self.pushControllerType == nowLocationTitle){
        self.title = @"现居住地";
    }
    self.oneArray = [NSArray array];
    self.twoArray = [NSArray array];
    [self getDataForJson];
    [self addSubView];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"area" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.numberArray = [NSMutableArray array];
    self.nameArray = [NSMutableArray array];
    // 一级数组
    self.oneArray = dic[@"plist"];
    for (NSDictionary *dict in self.oneArray) {
        NSString *name = dict[@"dicValue"];
        NSString *num = dict[@"dicKey"];
        [self.nameArray addObject:name];
        [self.numberArray addObject:num];
    }
    
    // 二级数组
    self.twoArray = dic[@"clist"];
    
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"JobPlaceVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.text = self.nameArray[indexPath.row];
    cell.textLabel.textColor = Color(138, 138, 138);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    JobPlaceSecondVC *placeSecond = [[JobPlaceSecondVC alloc] init];
    
    placeSecond.titleName = self.nameArray[indexPath.row];
    placeSecond.dicKey = self.numberArray[indexPath.row];
    placeSecond.twoArray = self.twoArray;
    
    placeSecond.pushControllerType = self.pushControllerType;
    [self.navigationController pushViewController:placeSecond animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

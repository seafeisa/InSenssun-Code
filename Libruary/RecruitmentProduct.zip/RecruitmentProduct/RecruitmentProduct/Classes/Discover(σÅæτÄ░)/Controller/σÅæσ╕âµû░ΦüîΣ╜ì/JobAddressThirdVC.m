//
//  JobAddressThirdVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JobAddressThirdVC.h"
#import "Common.h"
#import "newJobAddressViewController.h"

@interface JobAddressThirdVC ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *cArray;

@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic, strong) NSMutableArray *keys;


@end

@implementation JobAddressThirdVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if ([self.bigTitleName isEqualToString:self.titleName]) {
        self.title = self.titleName;

        self.titleStr = self.titleName;

    } else {
        NSArray *arr = @[self.bigTitleName, @"-", self.titleName];
        self.titleStr = [arr componentsJoinedByString:@""];
        self.title = self.titleStr;
    }
    
    
    
    [self getData];
    [self addSubView];
}

- (void)getData
{


    self.cArray = [NSMutableArray array];
    self.keys = [NSMutableArray array];
    for (NSDictionary *dic in self.alistArray) {
        if (dic[@"areaParentId"] == self.dickey) {
            NSString *str = dic[@"dicValue"];

            NSString *key = dic[@"dicKey"];
            [self.cArray addObject:str];
            [self.keys addObject:key];
        }
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.cArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"addressThirdVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.cArray[indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = self.cArray[indexPath.row];
    NSArray *arr = @[self.titleStr, str];
    NSString *city = [arr componentsJoinedByString:@"-"];
    
    MYLog(@"%@", city);

    NSString *key = self.keys[indexPath.row];
    
    NSString *keyStr = [NSString stringWithFormat:@"%@-%@-%@", self.firstDickey, self.dickey, key];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Address"] = city;
    dic[@"nowLocationKey"] = keyStr;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobAddress" object:dic];
    
    int index = (int)[[self.navigationController viewControllers] indexOfObject:self];
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:(index - 3)] animated:YES];
    
    MYLog(@"%@", keyStr);
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

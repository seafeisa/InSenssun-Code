//
//  ZWNameVC.m
//  RecruitmentProduct
//
//  Created by zy on 16/5/24.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "ZWNameVC.h"
#import "Common.h"

@interface ZWNameVC ()

@property (nonatomic, strong) UITextField *textF;

@end

@implementation ZWNameVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    self.title = @"职位名称";
    self.view.backgroundColor = Color(238, 238, 238);
    _textF = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, screenW, 40)];
    _textF.backgroundColor = [UIColor whiteColor];
    _textF.text = self.name;
    _textF.placeholder = @"请输入职位名称";
    [self.view addSubview:_textF];
    
    [self addRightButton];
    
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionZWnameButton:)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
}

- (void)actionZWnameButton:(UIButton *)btn
{
    if (_textF.text.length > 0 && _textF.text.length <= 30) {
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        dic[@"zwname"] = _textF.text;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ZWname" object:dic];
        [self.navigationController popViewControllerAnimated:YES];
    } else if (_textF.text.length == 0) {
        UIAlertView *altView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"职位名称不能为空!!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [altView show];
    } else if (_textF.text.length > 30) {
        UIAlertView *altView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"职位名称不能超过30个字符!!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [altView show];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

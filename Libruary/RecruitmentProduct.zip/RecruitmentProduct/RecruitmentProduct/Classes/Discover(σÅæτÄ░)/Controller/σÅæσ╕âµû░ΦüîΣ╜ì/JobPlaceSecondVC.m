//
//  JobPlaceSecondVC.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import "JobPlaceSecondVC.h"
#import "Common.h"

@interface JobPlaceSecondVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *placeKeys;

@end

@implementation JobPlaceSecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.titleName;
    [self getData];
    [self addSubView];
}

- (void)getData
{
    self.placeKeys = [NSMutableArray array];
    self.nameArray = [NSMutableArray array];
    for (NSDictionary *dic in self.twoArray) {
        if (dic[@"areaParentId"] == self.dicKey) {
            NSString *name = dic[@"dicValue"];

            NSString *key = dic[@"dicKey"];
            [self.nameArray addObject:name];
            [self.placeKeys addObject:key];
        }
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"jobPlaceSecondVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.nameArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str  = [NSString stringWithFormat:@"%@-%@", self.titleName, self.nameArray[indexPath.row]];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Place"] = str;
    dic[@"placeKey"] = self.placeKeys[indexPath.row];
    
    if (self.pushControllerType == 1) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"JobPlace" object:dic];
        MYLog(@"111111");
    }else if (self.pushControllerType == 2){
      [[NSNotificationCenter defaultCenter] postNotificationName:@"nowLocation" object:dic];
         MYLog(@"22222");
    }
    
 
    
    
    
    int index = (int)[[self.navigationController viewControllers] indexOfObject:self];
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:(index - 2)] animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

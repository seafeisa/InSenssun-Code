//
//  newJobTagViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 亮点标签
 */

#import "newJobTagViewController.h"
#import "QYJobTagcell.h"
#import "Common.h"
#import "AppDelegate.h"
#import "zyNavigationItemTool.h"

@interface newJobTagViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) QYJobTagcell *cell;

@property (nonatomic, strong) NSMutableArray *boolArray;

@property (nonatomic, strong) NSMutableArray *tagArray;

@property (nonatomic) BOOL isCell;

@property (nonatomic, strong) NSMutableArray *arry;

@property (nonatomic, retain) NSIndexPath* selectedIndexpath;

@property (nonatomic, strong) NSMutableArray *saveTitleArr;

@property (nonatomic, strong) NSMutableArray *keyArr;

@property (nonatomic, strong) NSMutableArray *indexpathArr;

@property (nonatomic, copy) NSString *titleStrs;

@property (nonatomic, strong) NSMutableArray *saveKeyArr;

@property (nonatomic, copy) NSString *keyStrs;

@end

@implementation newJobTagViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedIndexpath = nil;
    // Do any additional setup after loading the view.
    self.title = @"亮点标签";

    [self addSubView];
    [self getDataForJson];
    [self addRightButton];
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionRightButton)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    [zyNavigationItemTool setUpLeftBtnWithTarget:self action:@selector(actionLeftButton) iamge:[UIImage imageNamed:@"nav_back"] Title:nil];
}
/**
 *   点击返回navigationBar
 */
-(void)actionLeftButton{
     [[NSNotificationCenter defaultCenter] postNotificationName:@"tagStrsNotifi" object:nil];
     [self.navigationController popViewControllerAnimated:YES];
}
/**
 *  点击完成navigationBar
 */
-(void)actionRightButton{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"str"] = _titleStrs;
    dict[@"key"] = _keyStrs;
    
     [[NSNotificationCenter defaultCenter] postNotificationName:@"tagStrsNotifi" object:dict];
    [self.navigationController popViewControllerAnimated:YES];
}



-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [appDelegate.appDefault removeObjectForKey:@"indexpath"];
}
-(NSMutableArray *)indexpathArr{
    if (!_indexpathArr) {
        _indexpathArr = [NSMutableArray array];
    }
    return _indexpathArr;
}
-(NSMutableArray *)saveTitleArr{
    if (!_saveTitleArr) {
        _saveTitleArr = [NSMutableArray array];
    }
    return _saveTitleArr;
}
-(NSMutableArray *)saveKeyArr{
    if (!_saveKeyArr) {
        _saveKeyArr = [NSMutableArray array];
    }
    return _saveKeyArr;
}
- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"lightpoint" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.nameArray = [NSMutableArray array];
    self.keyArr = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        NSString *name = dic[@"dicValue"];
        NSString *key = dic[@"dicKey"];
        [self.nameArray addObject:name];
        [self.keyArr addObject:key];
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobTagVC";
    self.cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
        _cell = [[QYJobTagcell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    
    if(self.selectedIndexpath && [self.selectedIndexpath isEqual:indexPath])
    {
        _cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else
    {
        _cell.accessoryType = UITableViewCellAccessoryNone;
    }
    _cell.textLabel.text = self.nameArray[indexPath.row];
    _cell.isShow = @"0";
    _cell.image.tag = indexPath.row;
    self.tagArray = [NSMutableArray array];
    self.boolArray = [NSMutableArray array];
    for (int i = 0; i < self.nameArray.count; i++) {
        [self.boolArray addObject:_cell.isShow];
    }
    NSString *indexpathStr = [NSString stringWithFormat:@"%ld",indexPath.row];
    NSArray *arr = [appDelegate.appDefault objectForKey:@"indexpath"];
    MYLog(@"%@>>>>>>",arr);
    for (NSString *str in arr) {
        if ([str isEqualToString:indexpathStr]) {
           _cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }

    return _cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//
//    // 单选
//    if (self.selectedIndexpath && ![self.selectedIndexpath isEqual:indexPath]) {
//        UITableViewCell *sRow = [tableView cellForRowAtIndexPath:self.selectedIndexpath];
//        sRow.accessoryType = UITableViewCellAccessoryNone;
//        sRow.textLabel.textColor= [UIColor blackColor];
//    }
//    self.selectedIndexpath = indexPath;
//    UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
//    [selectedCell setAccessoryType:UITableViewCellAccessoryCheckmark];
//    
//    [self.tableView reloadData];
//    selectedCell.textLabel.textColor= zyMainColor
    
    
    NSString *nameStr = self.nameArray[indexPath.row];
    NSString *keyStr = self.keyArr[indexPath.row];
    // 多选
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    
    
   if (indexPath.row == self.selectedIndexpath.row) {
       
      
        [self.saveTitleArr removeObject:nameStr];
        [self.indexpathArr removeObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
        [self.saveKeyArr removeObject:keyStr];
        cell.accessoryType = UITableViewCellAccessoryNone;
  
       }

        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            if (self.saveTitleArr.count < 8) {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
                [self.saveTitleArr addObject:nameStr];
                [self.saveKeyArr addObject:keyStr];
                [self.indexpathArr addObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
            }
        }else{
               cell.accessoryType = UITableViewCellAccessoryNone;
                [self.saveTitleArr removeObject:nameStr];
                [self.indexpathArr removeObject:[NSString stringWithFormat:@"%ld",indexPath.row]];
            [self.saveKeyArr removeObject:keyStr];

        }
    
    if (self.saveTitleArr.count > 7) {
        [self pushAlertViewWithTitle:@"最多只能选择8个亮点标签,您已经达到上限"];
    }
   // MYLog(@"%@",self.saveTitleArr);
    [appDelegate.appDefault setObject:self.indexpathArr forKey:@"indexpath"];
    [appDelegate.appDefault synchronize];
    
    NSString *titleStrs = [self.saveTitleArr componentsJoinedByString:@","];
    _titleStrs = titleStrs;
   
    NSString *keyStrs = [self.saveKeyArr componentsJoinedByString:@","];
    _keyStrs = keyStrs;
    

    
   }
-(void)pushAlertViewWithTitle:(NSString *)title{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:title delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    [NSTimer scheduledTimerWithTimeInterval:2.30f
                                     target:self
                                   selector:@selector(applyPositiTimerFireMethod:)
                                   userInfo:alert
                                    repeats:YES];
    [alert show];
}
- (void)applyPositiTimerFireMethod:(NSTimer*)theTimer//弹出框
{
    UIAlertView *alert = (UIAlertView*)[theTimer userInfo];
    [alert dismissWithClickedButtonIndex:0 animated:NO];
    alert =NULL;
}


@end

//
//  newJobNumberViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newJobNumberViewController : UIViewController

@property (nonatomic, strong) UITableView *tableView;

@end

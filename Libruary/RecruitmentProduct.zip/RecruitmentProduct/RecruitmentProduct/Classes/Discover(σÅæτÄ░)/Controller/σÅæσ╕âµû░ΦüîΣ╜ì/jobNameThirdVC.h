//
//  jobNameThirdVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/26.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jobNameThirdVC : UIViewController

/**
 *  三级数组
 */
@property (nonatomic, strong) NSArray *threeArray;

@property (nonatomic, strong) NSString *titleName;

@property (nonatomic, strong) NSString *dicKey;

@end

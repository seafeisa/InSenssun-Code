//
//  newJobNatureViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 发布简历职位性质
 */

#import "newJobNatureViewController.h"
#import "Common.h"

@interface newJobNatureViewController ()<UITableViewDelegate, UITableViewDataSource>

/**
 *  4.25新增
 */
@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *keyArray;

@end

@implementation newJobNatureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"职位性质";
    [self getDataForJson];
    [self addSubView];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"zhiweixingzhi" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.nameArray = [NSMutableArray array];
    self.keyArray = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        NSString *name = dic[@"dicValue"];
        NSString *key = dic[@"dicKey"];
        [self.nameArray addObject:name];
        [self.keyArray addObject:key];
    }
    
    
    
}



- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.bounces = NO;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.nameArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobNatureVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.nameArray[indexPath.row];
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /**
     *  4.25新增 通知传值
     */
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Nature"] = self.nameArray[indexPath.row];
    dic[@"natureKey"] = self.keyArray[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobNature" object:dic];
    
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

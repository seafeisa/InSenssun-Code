//
//  newJobWriteViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 职位描述
 */

#import "newJobWriteViewController.h"

@interface newJobWriteViewController ()

@property (nonatomic, strong) UITextView *JobWrite;

@end

@implementation newJobWriteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"职位描述";
    [self addRightButton];
    [self addSub];
}

- (void)addSub
{
    self.JobWrite = [[UITextView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.JobWrite.text = self.describe;
    [self.view addSubview:self.JobWrite];
}

- (void)addRightButton
{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]
                                    initWithTitle:@"完成" style:(UIBarButtonItemStylePlain) target:self action:@selector(actionRightButton)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
}

- (void)actionRightButton {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Write"] = self.JobWrite.text;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobWrite" object:dic];
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  newJobWagesViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 职位月薪
 */

#import "newJobWagesViewController.h"
#import "Common.h"

@interface newJobWagesViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *JobWages;

@property (nonatomic, strong) NSMutableArray *salaryKeys;
@end

@implementation newJobWagesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"职位月薪";
    [self addSubView];
    [self getDataForJson];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"salary" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.JobWages = [NSMutableArray array];
    self.salaryKeys = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        NSString *str = dic[@"dicValue"];
        NSString *key = dic[@"dicKey"];
        [self.salaryKeys addObject:key];
        [self.JobWages addObject:str];
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.JobWages.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobWagesVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.JobWages[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Wages"] = self.JobWages[indexPath.row];
    dic[@"salaryKey"] = self.salaryKeys[indexPath.row];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobWages" object:dic];
    
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

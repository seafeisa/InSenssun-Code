//
//  newJobNumberViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 招聘人数
 */

#import "newJobNumberViewController.h"
#import "Common.h"

@interface newJobNumberViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSArray *arr;

@end

@implementation newJobNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"招聘人数";
    self.arr = @[@"1-3", @"3-5", @"5-10", @"10-50", @"50-100"];
  
}




#pragma mark - Table view data source





- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobNumberVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.arr[indexPath.row];
    return cell;;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Number"] = self.arr[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobNumber" object:dic];
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

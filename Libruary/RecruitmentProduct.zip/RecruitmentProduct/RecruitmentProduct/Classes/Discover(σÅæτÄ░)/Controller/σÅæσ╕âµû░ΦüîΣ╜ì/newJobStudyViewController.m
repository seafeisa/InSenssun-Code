//
//  newJobStudyViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

/**
 *  4.18新增 学历要求
 */

#import "newJobStudyViewController.h"
#import "Common.h"

@interface newJobStudyViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *JobStudy;

@property (nonatomic, strong) NSMutableArray *studyKeys;

@end

@implementation newJobStudyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"学历要求";
    [self addSubView];
    [self getDataForJson];
}

- (void)getDataForJson
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"education" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    self.JobStudy = [NSMutableArray array];

    self.studyKeys = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        NSString *array = dic[@"dicValue"];
        NSString *key = dic[@"dicKey"];
        [self.JobStudy addObject:array];
        [self.studyKeys addObject:key];
    }
}

- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.JobStudy.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"newJobStudyVC";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    }
    cell.textLabel.textColor = Color(138, 138, 138);
    cell.textLabel.text = self.JobStudy[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    dic[@"Study"] = self.JobStudy[indexPath.row];

    dic[@"studyKey"] = self.studyKeys[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JobStudy" object:dic];
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

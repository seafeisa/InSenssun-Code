//
//  newJobClassViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newJobClassViewController : UIViewController

@property (nonatomic) BOOL isResume;

@property (nonatomic, assign) int pushControllerType;

@property (nonatomic, strong) NSString *shuang;

@end

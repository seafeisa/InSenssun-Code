//
//  newJobPlaceViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/18.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newJobPlaceViewController : UIViewController
typedef enum{
    
    searchPlaceTitle = 0,//
    searchResumePlaceTitle,  // 人才搜索
    nowLocationTitle
}placeTitleType;

@property (nonatomic, assign) NSInteger pushControllerType;


@end

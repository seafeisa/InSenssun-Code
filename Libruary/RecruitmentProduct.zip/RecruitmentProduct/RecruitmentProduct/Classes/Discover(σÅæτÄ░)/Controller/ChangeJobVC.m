//
//  QYJobViewController.m
//  RecruitmentProduct
//
//  Created by andorid on 16/4/15.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//
/**
 *  4.27日 新增修改职位
 */

#import "ChangeJobVC.h"
#import "Common.h"
#import "UIView+ZYFrame.h"
#import "QYjobTableViewCell.h"
#import "newJobNameViewController.h"
#import "MHActionSheet.h"
#import "newJobNatureViewController.h"
#import "newJobClassViewController.h"
#import "newJobNumberViewController.h"
#import "newJobStudyViewController.h"
#import "newJobExpViewController.h"
#import "newJobWagesViewController.h"
#import "newJobWriteViewController.h"
#import "newJobTagViewController.h"
#import "newJobAddressViewController.h"
#import "newJobDateViewController.h"
#import "newJobAcceptViewController.h"
#import "newJobToppppViewController.h"
#import "newJobReplyViewController.h"
#import "newJobPlaceViewController.h"
#import "newJobPhoneViewController.h"
#import "zyzpHttpTool.h"



@interface ChangeJobVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

// 表尾view
@property (nonatomic, strong) UIView *BWview;

// 名字array
@property (nonatomic, strong) NSArray *nameArray;


/**
 *  4.18新增 全局cell
 */
@property (nonatomic, strong) QYjobTableViewCell *cell;


/**
 *  4.25新增  JobName
 */
@property (nonatomic, strong) NSString *JobName;

/**
 *  招聘人数
 */
@property (nonatomic, strong) NSString *JobNumber;

/**
 *  学历要求
 */
@property (nonatomic, strong) NSString *JobStudy;

/**
 *  工作经验
 */
@property (nonatomic, strong) NSString *JobExp;

/**
 *  职位月薪
 */
@property (nonatomic, strong) NSString *JobWages;

/**
 *  职位描述
 */
@property (nonatomic, strong) NSString *JobWrite;

/**
 *  职位申请回复
 */
@property (nonatomic, strong) NSString *JobReply;

/**
 *  联系方式
 */
@property (nonatomic, strong) NSString *JobPhone;

/**
 *  简历接收设置
 */
@property (nonatomic, strong) NSString *JobAccept;

/**
 *  4.26 职位发布地点
 */
@property (nonatomic, strong) NSString *JobAddress;

/**
 *  职位类别
 */
@property (nonatomic, strong) NSString *JobClass;

/**
 *  工作地址
 */
@property (nonatomic, strong) NSString *JobPlace;

/**
 *  4.27新增
 */
@property (nonatomic, strong) NSArray *allArray;

@end



@implementation ChangeJobVC


- (void)viewDidLoad {
    [super viewDidLoad];
    // 4.15 新增 title
    self.title = @"修改职位";
    
    self.nameArray = @[@"职位性质", @"职位名称", @"职位类别", @"招聘人数", @"学历要求", @"经验要求", @"职位月薪", @"职位描述", @"亮点标签", @"职位发布地点", @"发布截止日期", @"简历接收设置", @"高级发布设置", @"职位申请回复", @"工作地址", @"联系方式"];
    NSString *str = [NSString stringWithFormat:@"%@ %ld", _model.jobNum, (long)_model.sort];
    self.allArray = @[_model.jobNature, _model.jobName, _model.jobMainType, _model.personCount, _model.education, _model.experience, _model.salary, _model.jobDesc, _model.brightTag, _model.publishArea, _model.finallyDate, _model.receiveSet, str, _model.jobReply, _model.jobArea, _model.contactInfo];
    
    
//    [self addUIView];
//    [self addSubView];
//    [self getdata];
//    [self getDataForUrl];
}

/**
 *  4.27新增
 */
- (void)getDataForUrl
{
    NSString *url = [baseUrl stringByAppendingString:@"updateJob.htm"];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"jobId"] = self.model.jobId;
    parameters[@"jobNature"] = self.model.jobNature;
    parameters[@"jobName"] = _model.jobName;
    parameters[@"jobMainType"] = _model.jobMainType;
    parameters[@"personCount"] = _model.personCount;
    parameters[@"education"] = _model.education;
    parameters[@"experience"] = _model.experience;
    parameters[@"salary"] = _model.salary;
    parameters[@"jobDesc"] = _model.jobDesc;
    parameters[@"brightTag"] = _model.brightTag;
    parameters[@"publishArea"] = _model.publishArea;
    parameters[@"jobArea"] = _model.jobArea;
    parameters[@"finallyDate"] = _model.finallyDate;
    parameters[@"receiveSet"] = _model.receiveSet;
    parameters[@"jobNum"] = _model.jobNum;
    parameters[@"sort"] = _model.sort;
    parameters[@"jobReply"] = _model.jobReply;
    parameters[@"contactInfo"] = _model.contactInfo;
    parameters[@"releaseStatus"] = _model.releaseStatus;
    

    [zyzpHttpTool GET:url parameters:parameters progress:^{
        
    } success:^(id responseObject) {
        
        
        
    } failure:^(NSError *error) {
        MYLog(@"%@", error);
    }];
}

/**
 *  4.25新增
 */

- (void)getdata
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(valueFromNotifi:) name:@"JobNature" object:nil];
    // 职位名称
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobName:) name:@"JobName" object:nil];
    // 招聘人数
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobNumber:) name:@"JobNumber" object:nil];
    // 学历要求
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobStudy:) name:@"JobStudy" object:nil];
    // 工作经验
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobExp:) name:@"JobExp" object:nil];
    // 职位月薪
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWages:) name:@"JobWages" object:nil];
    // 职位描述
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobWrite:) name:@"JobWrite" object:nil];
    // 职位申请回复
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobReply:) name:@"JobReply" object:nil];
    // 联系方式
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobPhone:) name:@"JobPhone" object:nil];
    // 简历接收设置
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobAccept:) name:@"JobAccept" object:nil];
    // 4.26 职位发布地点
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobAddress:) name:@"JobAddress" object:nil];
    // 职位类别
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobClass:) name:@"JobClass" object:nil];
    // 工作地址
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(JobPlace:) name:@"JobPlace" object:nil];
}

/**
 *  4.25新增  好多通知方法😂
 */
- (void)valueFromNotifi:(NSNotification *)notifi{
    NSDictionary *dictionary = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobNature = dictionary[@"Nature"];
    [self.tableView reloadData];
}

/**
 *  职位名称
 */

- (void)JobName:(NSNotification *)notifi{
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobName = dic[@"Name"];
    [self.tableView reloadData];
}

/**
 *  学历要求
 */
- (void)JobStudy:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobStudy = dic[@"Study"];
    [self.tableView reloadData];
}

// 招聘人数
- (void)JobNumber:(NSNotification *)notifi{
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobNumber = dic[@"Number"];
    [self.tableView reloadData];
}

/**
 *  工作经验
 */
- (void)JobExp:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobExp = dic[@"Exp"];
    [self.tableView reloadData];
}

/**
 *  职位月薪
 */
- (void)JobWages:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWages = dic[@"Wages"];
    [self.tableView reloadData];
}

/**
 *  职位描述
 */
- (void)JobWrite:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobWrite = dic[@"Write"];
    [self.tableView reloadData];
}

/**
 *  职位申请回复
 */
- (void)JobReply:(NSNotification *)notofi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notofi.object];
    self.JobReply = dic[@"Reply"];
    [self.tableView reloadData];
}

/**
 *  联系方式
 */
- (void)JobPhone:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPhone = dic[@"Phone"];
    [self.tableView reloadData];
}

/**
 *  简历接收设置
 */
- (void)JobAccept:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobAccept = dic[@"Accept"];
    [self.tableView reloadData];
}

/**
 *  4.26 职位发布地点
 */
- (void)JobAddress:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobAddress = dic[@"Address"];
    [self.tableView reloadData];
}

/**
 *  职位类别
 */
- (void)JobClass:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobClass = dic[@"Classa"];
    [self.tableView reloadData];
}

/**
 *  工作地址
 */
- (void)JobPlace:(NSNotification *)notifi {
    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:notifi.object];
    self.JobPlace = dic[@"Place"];
    [self.tableView reloadData];
}




- (void)addSubView
{
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:(UITableViewStylePlain)];
    self.tableView.tableFooterView = self.BWview;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //    self.tableView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.tableView];
}

// 预览button的点击实现
- (void)actionYLbutton:(UIButton *)btn
{
    NSLog(@"预览");
}

// 保存为未发布button的点击实现
- (void)actionBCbutton:(UIButton *)btn
{
//    NSLog(@"保存为未发布");
}

// cell个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.allArray.count;
}

/**
 *  cell高度
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    newJobNameViewController *jobName = [[newJobNameViewController alloc] init];
    static NSString *identifier = @"QYjobVC";
    _cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    _cell = [[QYjobTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
    
    if (indexPath.row == 0) {
        _cell.lastLabel.text = self.JobNature;
    } else if (indexPath.row == 1) {
        // 职位名称
        _cell.lastLabel.text = self.JobName;
    } else if (indexPath.row == 2) {
        // 职位类别
        _cell.lastLabel.text = self.JobClass;
    } else if (indexPath.row == 3) {
        _cell.lastLabel.text = self.JobNumber;
    } else if (indexPath.row == 4) {
        _cell.lastLabel.text = self.JobStudy;
    } else if (indexPath.row == 5) {
        _cell.lastLabel.text = self.JobExp;
    } else if (indexPath.row == 6) {
        _cell.lastLabel.text = self.JobWages;
    } else if (indexPath.row == 7) {
        _cell.lastLabel.text = self.JobWrite;
    } else if (indexPath.row == 8) {
        // 亮点标签
    } else if (indexPath.row == 9) {
        // 职位发布地点
        _cell.lastLabel.text = self.JobAddress;
    } else if (indexPath.row == 10) {
        // 发布截止日期
    } else if (indexPath.row == 11) {
        // 简历接收设置
        _cell.lastLabel.text = self.JobAccept;
    } else if (indexPath.row == 12) {
        // 高级发布设置
    } else if (indexPath.row == 13) {
        // 职位申请回复
        _cell.lastLabel.text = self.JobReply;
    } else if (indexPath.row == 14) {
        // 工作地址
        _cell.lastLabel.text = self.JobPlace;
    } else if (indexPath.row == 15) {
        // 联系方式
        _cell.lastLabel.text = self.JobPhone;
    }
    
    _cell.lastLabel.text = self.allArray[indexPath.row];
    _cell.lastLabel.textColor = Color(138, 138, 138);
    _cell.lastLabel.textAlignment = NSTextAlignmentRight;
    _cell.nameLable.textColor = Color(138, 138, 138);
    _cell.nameLable.text = self.nameArray[indexPath.row];
    _cell.imageV.image = [UIImage imageNamed:@"find_go"];
    return _cell;
}



/**
 *  cell点击方法
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        newJobNatureViewController *newJobNatureVC = [[newJobNatureViewController alloc] init];
        [self.navigationController pushViewController:newJobNatureVC animated:YES];
        
    } else if (indexPath.row == 1) {
        newJobNameViewController *jobName = [[newJobNameViewController alloc] init];
        [self.navigationController pushViewController:jobName animated:YES];
    } else if (indexPath.row == 2) {
        newJobClassViewController *newJobClass = [[newJobClassViewController alloc] init];
        [self.navigationController pushViewController:newJobClass animated:YES];
    } else if (indexPath.row == 3) {
        newJobNumberViewController *newJobNumber = [[newJobNumberViewController alloc] init];
        [self.navigationController pushViewController:newJobNumber animated:YES];
    } else if (indexPath.row == 4) {
        newJobStudyViewController *newJobStudy = [[newJobStudyViewController alloc] init];
        [self.navigationController pushViewController:newJobStudy animated:YES];
    } else if (indexPath.row == 5) {
        newJobExpViewController *newJobExp = [[newJobExpViewController alloc] init];
        [self.navigationController pushViewController:newJobExp animated:YES];
    } else if (indexPath.row == 6) {
        newJobWagesViewController *newJobWages = [[newJobWagesViewController alloc] init];
        [self.navigationController pushViewController:newJobWages animated:YES];
    } else if (indexPath.row == 7) {
        newJobWriteViewController *newJobWrite = [[newJobWriteViewController alloc] init];
        [self.navigationController pushViewController:newJobWrite animated:YES];
    } else if (indexPath.row == 8) {
        newJobTagViewController *newJobTag = [[newJobTagViewController alloc] init];
        [self.navigationController pushViewController:newJobTag animated:YES];
    } else if (indexPath.row == 9) {
        newJobAddressViewController *newJobAddress = [[newJobAddressViewController alloc] init];
        [self.navigationController pushViewController:newJobAddress animated:YES];
    } else if (indexPath.row == 10) {
        newJobDateViewController *newJobDate = [[newJobDateViewController alloc] init];
        [self.navigationController pushViewController:newJobDate animated:YES];
    } else if (indexPath.row == 11) {
        newJobAcceptViewController *newJobAccept = [[newJobAcceptViewController alloc] init];
        [self.navigationController pushViewController:newJobAccept animated:YES];
    } else if (indexPath.row == 12) {
        newJobToppppViewController *newJobTop = [[newJobToppppViewController alloc] init];
        [self.navigationController pushViewController:newJobTop animated:YES];
    } else if (indexPath.row == 13) {
        newJobReplyViewController *newJobReply = [[newJobReplyViewController alloc] init];
        [self.navigationController pushViewController:newJobReply animated:YES];
    } else if (indexPath.row == 14) {
        newJobPlaceViewController *newJobPlace = [[newJobPlaceViewController alloc] init];
        [self.navigationController pushViewController:newJobPlace animated:YES];
    } else if (indexPath.row == 15) {
        newJobPhoneViewController *newJobPhone = [[newJobPhoneViewController alloc] init];
        [self.navigationController pushViewController:newJobPhone animated:YES];
    }
}

- (void)addUIView
{
    // 表尾view
    self.BWview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 150)];
    self.BWview.backgroundColor = [UIColor whiteColor];
    
    // 预览职位按钮
    UIButton *ylButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    //    ylButton.frame = CGRectMake(23, 30, 158, 44);
    ylButton.x = 23;
    ylButton.y = 30;
    ylButton.width = screenW - 46;
    ylButton.height = 44;
    
    [ylButton setTitle:@"保存" forState:0];
    ylButton.titleLabel.font = [UIFont systemFontOfSize:18.0];
    [ylButton.layer setCornerRadius:5.0];
    [ylButton setTintColor:[UIColor whiteColor]];
    [ylButton addTarget:self action:@selector(actionYLbutton:) forControlEvents:(UIControlEventTouchUpInside)];
    ylButton.backgroundColor = zyMainColor;
    [self.BWview addSubview:ylButton];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

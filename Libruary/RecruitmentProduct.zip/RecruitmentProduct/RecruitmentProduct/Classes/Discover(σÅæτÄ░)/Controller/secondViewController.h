//
//  secondViewController.h
//  RecruitmentProduct
//
//  Created by andorid on 16/3/31.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController

@property (nonatomic, strong) NSString *recruitmentId;

@end

//
//  secondVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/1.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondVC : UIViewController

@property (nonatomic, strong) NSString *Id;

@end

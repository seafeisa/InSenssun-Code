//
//  interviewVC.h
//  RecruitmentProduct
//
//  Created by andorid on 16/4/7.
//  Copyright © 2016年 RunShengInformation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface interviewVC : UIViewController

@property (nonatomic, strong) NSString *per;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) id responseObject;

@end
